// Public community-server build. Deploy this entire file as the Worker entry point.
// Required bindings/secrets: DB, JWT_SECRET, ADMIN_TOKEN. Optional var: SERVER_NAME.
const DEFAULT_SERVER_MODE = 'private';
const DEFAULT_SERVER_NAME = 'Private Ratings';
const PBKDF2_ITERATIONS = 100000;

const enc = new TextEncoder();
const dec = new TextDecoder();

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-headers': 'authorization, content-type',
  'access-control-allow-methods': 'GET, POST, PUT, DELETE, OPTIONS',
};
const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', ...CORS },
});
const now = () => Math.floor(Date.now() / 1000);
const modeFor = (env) => String(env.SERVER_MODE || DEFAULT_SERVER_MODE).toLowerCase() === 'public' ? 'public' : 'private';
const nameFor = (env) => String(env.SERVER_NAME || DEFAULT_SERVER_NAME).slice(0, 60);

// ---------- crypto ----------
const b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)))
  .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
const hmacKey = (secret) => crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
async function signToken(payload, secret) {
  const body = b64u(enc.encode(JSON.stringify(payload)));
  const sig = await crypto.subtle.sign('HMAC', await hmacKey(secret), enc.encode(body));
  return `${body}.${b64u(sig)}`;
}
async function verifyToken(token, secret) {
  try {
    const [body, sig] = token.split('.');
    if (!body || !sig) return null;
    const ok = await crypto.subtle.verify('HMAC', await hmacKey(secret), unb64u(sig), enc.encode(body));
    if (!ok) return null;
    const p = JSON.parse(dec.decode(unb64u(body)));
    return p.exp > Date.now() / 1000 ? p : null;
  } catch { return null; }
}
async function pbkdf2(password, salt) {
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' }, key, 256);
  return b64u(bits);
}
async function hashPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return `${b64u(salt)}:${await pbkdf2(password, salt)}`;
}
async function checkPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  return safeEqual(await pbkdf2(password, unb64u(salt)), hash);
}
function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

// ---------- authentication ----------
async function getUser(req, env) {
  const h = req.headers.get('authorization') || '';
  if (!h.startsWith('Bearer ')) return null;
  const p = await verifyToken(h.slice(7), env.JWT_SECRET);
  if (!p) throw new HttpError(401, 'Session expired. Please log in again.');
  const account = await env.DB.prepare('SELECT id, username, status FROM users WHERE id = ?').bind(p.uid).first();
  if (!account || account.status === 'suspended') throw new HttpError(403, 'This account is unavailable.');
  return { id: account.id, username: account.username };
}
function requireAdmin(req, env) {
  const h = req.headers.get('authorization') || '';
  if (!env.ADMIN_TOKEN || !h.startsWith('Bearer ') || !safeEqual(h.slice(7), env.ADMIN_TOKEN)) {
    throw new HttpError(403, 'Admin token required');
  }
}
const authResponse = async (env, id, username) => json({
  token: await signToken({ uid: id, name: username, exp: Math.floor(Date.now() / 1000) + 30 * 86400 }, env.JWT_SECRET),
  username,
});
async function readBody(req) {
  try { return await req.json(); } catch { throw new HttpError(400, 'Invalid JSON body'); }
}

// ---------- validation ----------
function cleanTags(raw) {
  if (raw === undefined || raw === null || raw === '') return [];
  const values = Array.isArray(raw) ? raw : String(raw).split(',');
  const out = [];
  const seen = new Set();
  for (const value of values) {
    const tag = String(value).trim().replace(/\s+/g, ' ');
    if (!tag) continue;
    if (tag.length > 24 || !/^[\p{L}\p{N}][\p{L}\p{N} ._+-]*$/u.test(tag)) {
      throw new HttpError(400, 'Tags must be 1-24 letters, numbers, spaces, dots, _ or -');
    }
    const key = tag.toLowerCase();
    if (!seen.has(key)) { seen.add(key); out.push(tag); }
    if (out.length > 8) throw new HttpError(400, 'Use no more than 8 tags');
  }
  return out;
}
function cleanItem(b, partial = false) {
  const out = {};
  if (!partial || b.name !== undefined) {
    const name = String(b.name ?? '').trim();
    if (!name || name.length > 100) throw new HttpError(400, 'Name is required (max 100 characters)');
    out.name = name;
  }
  if (!partial || b.description !== undefined) {
    const description = String(b.description ?? '').trim();
    if (description.length > 2000) throw new HttpError(400, 'Description is too long (max 2000 characters)');
    out.description = description;
  }
  if (!partial || b.image_url !== undefined) {
    const imageUrl = String(b.image_url ?? '').trim();
    if (imageUrl && !/^https?:\/\//i.test(imageUrl)) throw new HttpError(400, 'Image URL must start with http:// or https://');
    out.image_url = imageUrl;
  }
  if (!partial || b.tags !== undefined) out.tags = cleanTags(b.tags);
  return out;
}

// ---------- database helpers ----------
const ITEM_SQL = `
  SELECT i.id, i.name, i.description, i.image_url, i.added_by, i.status,
         COALESCE(ROUND(AVG(CASE WHEN r.status = 'published' THEN r.rating END), 2), 0) AS avg_rating,
         COUNT(CASE WHEN r.status = 'published' THEN r.id END) AS review_count
  FROM items i LEFT JOIN reviews r ON r.item_id = i.id`;

async function attachTags(env, rows) {
  if (!rows.length) return rows;
  const ids = rows.map(x => x.id);
  const slots = ids.map(() => '?').join(',');
  const { results } = await env.DB.prepare(
    `SELECT it.item_id, t.name FROM item_tags it JOIN tags t ON t.id = it.tag_id WHERE it.item_id IN (${slots}) ORDER BY t.name COLLATE NOCASE`
  ).bind(...ids).all();
  const byId = new Map(ids.map(id => [id, []]));
  for (const row of results) byId.get(row.item_id)?.push(row.name);
  return rows.map(row => ({ ...row, tags: byId.get(row.id) || [] }));
}
async function listItems(env, includeHidden = false) {
  const where = includeHidden ? '' : "WHERE i.status = 'published'";
  const { results } = await env.DB.prepare(`${ITEM_SQL} ${where} GROUP BY i.id ORDER BY i.id DESC`).all();
  return attachTags(env, results);
}
async function getItem(env, id, includeHidden = false) {
  const where = includeHidden ? 'WHERE i.id = ?' : "WHERE i.id = ? AND i.status = 'published'";
  const row = await env.DB.prepare(`${ITEM_SQL} ${where} GROUP BY i.id`).bind(id).first();
  if (!row) return null;
  return (await attachTags(env, [row]))[0];
}
async function saveTags(env, itemId, names) {
  await env.DB.prepare('DELETE FROM item_tags WHERE item_id = ?').bind(itemId).run();
  for (const name of names) {
    await env.DB.prepare('INSERT OR IGNORE INTO tags (name) VALUES (?)').bind(name).run();
    const tag = await env.DB.prepare('SELECT id FROM tags WHERE name = ? COLLATE NOCASE').bind(name).first();
    if (tag) await env.DB.prepare('INSERT OR IGNORE INTO item_tags (item_id, tag_id) VALUES (?, ?)').bind(itemId, tag.id).run();
  }
}
async function ipHash(req, env) {
  const ip = req.headers.get('cf-connecting-ip') || 'unknown';
  return b64u(await crypto.subtle.digest('SHA-256', enc.encode(ip + env.JWT_SECRET))).slice(0, 22);
}
function publicConfig(env) {
  const mode = modeFor(env);
  return {
    name: nameFor(env),
    mode,
    item_submission: mode === 'public' ? 'instant' : 'approval',
    login_required_to_add: true,
    tags_enabled: true,
    moderation_enabled: true,
  };
}

// ---------- routes ----------
async function handle(req, env) {
  const url = new URL(req.url);
  const path = url.pathname.replace(/\/+$/, '') || '/';
  const method = req.method;
  let m;
  if (method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  if (path === '/panel' && method === 'GET') return new Response(PANEL_HTML, { headers: { 'content-type': 'text/html; charset=utf-8', 'x-frame-options': 'DENY', 'referrer-policy': 'no-referrer', 'content-security-policy': "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src https: data:; connect-src 'self'" } });
  if (path === '/' && method === 'GET') return json({ app: 'rating-worker', ok: true, ...publicConfig(env) });
  if (path === '/api/config' && method === 'GET') return json(publicConfig(env));

  // Account creation and sign-in
  if (path === '/api/signup' && method === 'POST') {
    const { username = '', password = '' } = await readBody(req);
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) throw new HttpError(400, 'Username: 3-20 letters, numbers or _');
    if (['guest', 'anonymous', 'admin'].includes(username.toLowerCase())) throw new HttpError(400, 'That username is reserved');
    if (String(password).length < 8 || String(password).length > 200) throw new HttpError(400, 'Password must be at least 8 characters');
    try {
      const r = await env.DB.prepare('INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?)')
        .bind(username, await hashPassword(password), now()).run();
      return authResponse(env, r.meta.last_row_id, username);
    } catch (e) {
      if (String(e).includes('UNIQUE')) throw new HttpError(409, 'Username already taken');
      throw e;
    }
  }
  if (path === '/api/login' && method === 'POST') {
    const { username = '', password = '' } = await readBody(req);
    const user = await env.DB.prepare('SELECT id, username, password_hash, status FROM users WHERE username = ?').bind(username).first();
    if (!user || !(await checkPassword(password, user.password_hash))) throw new HttpError(401, 'Wrong username or password');
    if (user.status === 'suspended') throw new HttpError(403, 'This account is unavailable.');
    return authResponse(env, user.id, user.username);
  }

  // Profiles, follows, blocks, and private messaging
  if (path === '/api/me/profile' && method === 'PUT') {
    const user = await getUser(req, env);
    if (!user) throw new HttpError(401, 'Log in to edit your profile');
    const body = await readBody(req);
    const displayName = String(body.display_name ?? user.username).trim();
    const bio = String(body.bio ?? '').trim();
    const avatarUrl = String(body.avatar_url ?? '').trim();
    if (!displayName || displayName.length > 40) throw new HttpError(400, 'Display name must be 1-40 characters');
    if (bio.length > 280) throw new HttpError(400, 'Bio must be 280 characters or fewer');
    if (avatarUrl && !/^https:\/\//i.test(avatarUrl)) throw new HttpError(400, 'Avatar URL must use HTTPS');
    await env.DB.prepare('UPDATE users SET display_name = ?, bio = ?, avatar_url = ? WHERE id = ?')
      .bind(displayName, bio, avatarUrl, user.id).run();
    return json({ ok: true });
  }

  if (path === '/api/me/blocks' && method === 'GET') {
    const user = await getUser(req, env);
    if (!user) throw new HttpError(401, 'Log in to view blocked accounts');
    const { results } = await env.DB.prepare(
      'SELECT u.username, COALESCE(NULLIF(u.display_name, \'\'), u.username) AS display_name FROM user_blocks b JOIN users u ON u.id = b.blocked_id WHERE b.blocker_id = ? ORDER BY u.username COLLATE NOCASE'
    ).bind(user.id).all();
    return json({ users: results });
  }

  if ((m = path.match(/^\/api\/users\/([A-Za-z0-9_]{3,20})$/)) && method === 'GET') {
    const viewer = await getUser(req, env);
    const target = await env.DB.prepare(
      'SELECT id, username, COALESCE(NULLIF(display_name, \'\'), username) AS display_name, bio, avatar_url, created_at, status FROM users WHERE username = ? COLLATE NOCASE'
    ).bind(m[1]).first();
    if (!target || target.status === 'suspended') throw new HttpError(404, 'Profile not found');
    if (viewer && viewer.id !== target.id) {
      const blocked = await env.DB.prepare(
        'SELECT 1 FROM user_blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?) LIMIT 1'
      ).bind(viewer.id, target.id, target.id, viewer.id).first();
      if (blocked) throw new HttpError(403, 'This profile is unavailable.');
    }
    const counts = await env.DB.prepare(
      `SELECT
        (SELECT COUNT(*) FROM follows WHERE followed_id = ?) AS follower_count,
        (SELECT COUNT(*) FROM follows WHERE follower_id = ?) AS following_count,
        (SELECT COUNT(*) FROM items WHERE added_by_user_id = ? AND status = 'published') AS entry_count,
        (SELECT COUNT(*) FROM reviews WHERE user_id = ? AND status = 'published') AS review_count`
    ).bind(target.id, target.id, target.id, target.id).first();
    const following = viewer ? await env.DB.prepare(
      'SELECT 1 FROM follows WHERE follower_id = ? AND followed_id = ?'
    ).bind(viewer.id, target.id).first() : null;
    const followsYou = viewer ? await env.DB.prepare(
      'SELECT 1 FROM follows WHERE follower_id = ? AND followed_id = ?'
    ).bind(target.id, viewer.id).first() : null;
    const entries = await env.DB.prepare(
      `SELECT id, name, description, image_url, created_at FROM items
       WHERE added_by_user_id = ? AND status = 'published' ORDER BY created_at DESC, id DESC LIMIT 30`
    ).bind(target.id).all();
    const reviews = await env.DB.prepare(
      `SELECT r.id, r.item_id, i.name AS item_name, r.rating, r.text, r.created_at
       FROM reviews r JOIN items i ON i.id = r.item_id
       WHERE r.user_id = ? AND r.status = 'published' AND i.status = 'published'
       ORDER BY r.created_at DESC, r.id DESC LIMIT 30`
    ).bind(target.id).all();
    return json({
      profile: {
        username: target.username,
        display_name: target.display_name,
        bio: target.bio || '',
        avatar_url: target.avatar_url || '',
        created_at: target.created_at,
        follower_count: counts.follower_count,
        following_count: counts.following_count,
        entry_count: counts.entry_count,
        review_count: counts.review_count,
        is_following: !!following,
        follows_you: !!followsYou,
        is_self: !!viewer && viewer.id === target.id,
        can_message: !!viewer && !!following && !!followsYou && viewer.id !== target.id
      },
      entries: entries.results,
      reviews: reviews.results
    });
  }

  if ((m = path.match(/^\/api\/users\/([A-Za-z0-9_]{3,20})\/(followers|following)$/)) && method === 'GET') {
    const viewer = await getUser(req, env);
    const target = await env.DB.prepare('SELECT id, status FROM users WHERE username = ? COLLATE NOCASE').bind(m[1]).first();
    if (!target || target.status === 'suspended') throw new HttpError(404, 'User not found');
    if (viewer && viewer.id !== target.id) {
      const blocked = await env.DB.prepare(
        'SELECT 1 FROM user_blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?) LIMIT 1'
      ).bind(viewer.id, target.id, target.id, viewer.id).first();
      if (blocked) throw new HttpError(403, 'This list is unavailable.');
    }
    const joinColumn = m[2] === 'followers' ? 'followed_id' : 'follower_id';
    const resultColumn = m[2] === 'followers' ? 'follower_id' : 'followed_id';
    const { results } = await env.DB.prepare(
      `SELECT u.username, COALESCE(NULLIF(u.display_name, ''), u.username) AS display_name
       FROM follows f JOIN users u ON u.id = f.${resultColumn}
       WHERE f.${joinColumn} = ? AND u.status = 'active'
       AND NOT EXISTS (SELECT 1 FROM user_blocks b WHERE (b.blocker_id = ? AND b.blocked_id = u.id) OR (b.blocker_id = u.id AND b.blocked_id = ?))
       ORDER BY u.username COLLATE NOCASE LIMIT 200`
    ).bind(target.id, viewer?.id ?? -1, viewer?.id ?? -1).all();
    return json({ users: results });
  }

  if ((m = path.match(/^\/api\/users\/([A-Za-z0-9_]{3,20})\/(follow|block|report)$/)) && (method === 'POST' || method === 'DELETE')) {
    const user = await getUser(req, env);
    if (!user) throw new HttpError(401, 'Log in to use this feature');
    const target = await env.DB.prepare('SELECT id, username, status FROM users WHERE username = ? COLLATE NOCASE').bind(m[1]).first();
    if (!target || target.status === 'suspended') throw new HttpError(404, 'User not found');
    if (target.id === user.id) throw new HttpError(400, 'You cannot use this action on your own account');
    const action = m[2];

    if (action === 'follow') {
      if (method === 'POST') {
        const blocked = await env.DB.prepare(
          'SELECT 1 FROM user_blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?) LIMIT 1'
        ).bind(user.id, target.id, target.id, user.id).first();
        if (blocked) throw new HttpError(403, 'Following is unavailable for this account');
        await env.DB.prepare('INSERT OR IGNORE INTO follows (follower_id, followed_id, created_at) VALUES (?, ?, ?)')
          .bind(user.id, target.id, now()).run();
      } else {
        await env.DB.prepare('DELETE FROM follows WHERE follower_id = ? AND followed_id = ?').bind(user.id, target.id).run();
      }
      return json({ ok: true });
    }

    if (action === 'block') {
      if (method === 'POST') {
        await env.DB.batch([
          env.DB.prepare('INSERT OR IGNORE INTO user_blocks (blocker_id, blocked_id, created_at) VALUES (?, ?, ?)').bind(user.id, target.id, now()),
          env.DB.prepare('DELETE FROM follows WHERE (follower_id = ? AND followed_id = ?) OR (follower_id = ? AND followed_id = ?)').bind(user.id, target.id, target.id, user.id)
        ]);
      } else {
        await env.DB.prepare('DELETE FROM user_blocks WHERE blocker_id = ? AND blocked_id = ?').bind(user.id, target.id).run();
      }
      return json({ ok: true });
    }

    if (method !== 'POST') throw new HttpError(405, 'User reports cannot be deleted');
    const body = await readBody(req);
    const reason = String(body.reason || '').trim();
    if (!reason || reason.length > 500) throw new HttpError(400, 'Add a reason (max 500 characters)');
    const duplicate = await env.DB.prepare(
      "SELECT id FROM user_reports WHERE reporter_id = ? AND target_id = ? AND status = 'pending'"
    ).bind(user.id, target.id).first();
    if (duplicate) throw new HttpError(409, 'You already reported this account');
    await env.DB.prepare(
      "INSERT INTO user_reports (reporter_id, target_id, reason, status, created_at) VALUES (?, ?, ?, 'pending', ?)"
    ).bind(user.id, target.id, reason, now()).run();
    return json({ ok: true }, 201);
  }

  if (path === '/api/messages' && method === 'GET') {
    const user = await getUser(req, env);
    if (!user) throw new HttpError(401, 'Log in to view messages');
    const { results } = await env.DB.prepare(
      `SELECT u.username, COALESCE(NULLIF(u.display_name, ''), u.username) AS display_name,
        (SELECT body FROM direct_messages d WHERE (d.sender_id = ? AND d.recipient_id = u.id) OR (d.sender_id = u.id AND d.recipient_id = ?) ORDER BY d.created_at DESC, d.id DESC LIMIT 1) AS last_message,
        (SELECT created_at FROM direct_messages d WHERE (d.sender_id = ? AND d.recipient_id = u.id) OR (d.sender_id = u.id AND d.recipient_id = ?) ORDER BY d.created_at DESC, d.id DESC LIMIT 1) AS last_message_at,
        (SELECT COUNT(*) FROM direct_messages d WHERE d.sender_id = u.id AND d.recipient_id = ? AND d.read_at IS NULL) AS unread_count
       FROM users u WHERE u.id IN (SELECT sender_id FROM direct_messages WHERE recipient_id = ? UNION SELECT recipient_id FROM direct_messages WHERE sender_id = ?)
       AND u.status = 'active'
       AND NOT EXISTS (SELECT 1 FROM user_blocks b WHERE (b.blocker_id = ? AND b.blocked_id = u.id) OR (b.blocker_id = u.id AND b.blocked_id = ?))
       AND EXISTS (SELECT 1 FROM follows f1 WHERE f1.follower_id = ? AND f1.followed_id = u.id)
       AND EXISTS (SELECT 1 FROM follows f2 WHERE f2.follower_id = u.id AND f2.followed_id = ?)
       ORDER BY last_message_at DESC LIMIT 100`
    ).bind(user.id, user.id, user.id, user.id, user.id, user.id, user.id, user.id, user.id, user.id, user.id).all();
    return json({ conversations: results });
  }

  if ((m = path.match(/^\/api\/messages\/([A-Za-z0-9_]{3,20})$/)) && (method === 'GET' || method === 'POST')) {
    const user = await getUser(req, env);
    if (!user) throw new HttpError(401, 'Log in to use messages');
    const target = await env.DB.prepare('SELECT id, username, status FROM users WHERE username = ? COLLATE NOCASE AND status = \'active\'').bind(m[1]).first();
    if (!target) throw new HttpError(404, 'User not found');
    if (target.id === user.id) throw new HttpError(400, 'You cannot message yourself');
    const blocked = await env.DB.prepare(
      'SELECT 1 FROM user_blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?) LIMIT 1'
    ).bind(user.id, target.id, target.id, user.id).first();
    if (blocked) throw new HttpError(403, 'Messaging is unavailable for this account');
    const mutual = await env.DB.prepare(
      'SELECT 1 FROM follows a JOIN follows b ON a.follower_id = b.followed_id AND a.followed_id = b.follower_id WHERE a.follower_id = ? AND a.followed_id = ?'
    ).bind(user.id, target.id).first();
    if (!mutual) throw new HttpError(403, 'Direct messages are available between mutual followers only');

    if (method === 'POST') {
      const body = await readBody(req);
      const message = String(body.body ?? '').trim();
      if (!message || message.length > 2000) throw new HttpError(400, 'Message must be 1-2,000 characters');
      const recent = await env.DB.prepare(
        'SELECT COUNT(*) AS total FROM direct_messages WHERE sender_id = ? AND created_at > ?'
      ).bind(user.id, now() - 86400).first();
      if ((recent?.total ?? 0) >= 100) throw new HttpError(429, 'Daily message limit reached');
      const r = await env.DB.prepare(
        'INSERT INTO direct_messages (sender_id, recipient_id, body, created_at) VALUES (?, ?, ?, ?)'
      ).bind(user.id, target.id, message, now()).run();
      return json({ ok: true, id: r.meta.last_row_id }, 201);
    }

    const { results } = await env.DB.prepare(
      `SELECT id, sender_id, recipient_id, body, created_at, read_at
       FROM direct_messages WHERE (sender_id = ? AND recipient_id = ?) OR (sender_id = ? AND recipient_id = ?)
       ORDER BY created_at ASC, id ASC LIMIT 300`
    ).bind(user.id, target.id, target.id, user.id).all();
    await env.DB.prepare(
      'UPDATE direct_messages SET read_at = ? WHERE sender_id = ? AND recipient_id = ? AND read_at IS NULL'
    ).bind(now(), target.id, user.id).run();
    return json({ username: target.username, messages: results.map(message => ({ ...message, mine: message.sender_id === user.id })) });
  }

  // Public catalogue
  if (path === '/api/items' && method === 'GET') return json({ items: await listItems(env) });
  if (path === '/api/tags' && method === 'GET') {
    const { results } = await env.DB.prepare(
      "SELECT DISTINCT t.name FROM tags t JOIN item_tags it ON it.tag_id = t.id JOIN items i ON i.id = it.item_id WHERE i.status = 'published' ORDER BY t.name COLLATE NOCASE"
    ).all();
    return json({ tags: results.map(x => x.name) });
  }
  if ((m = path.match(/^\/api\/items\/(\d+)$/)) && method === 'GET') {
    const user = await getUser(req, env);
    const item = await getItem(env, +m[1]);
    if (!item) throw new HttpError(404, 'Item not found');
    const { results } = await env.DB.prepare(
      "SELECT id, author, rating, text, created_at FROM reviews WHERE item_id = ? AND status = 'published' ORDER BY created_at DESC, id DESC LIMIT 200"
    ).bind(+m[1]).all();
    const myReview = user ? await env.DB.prepare(
      'SELECT id, rating, text FROM reviews WHERE item_id = ? AND user_id = ?'
    ).bind(+m[1], user.id).first() : null;
    return json({ item, reviews: results, my_review: myReview });
  }

  // The same client endpoint has different behavior depending on server mode.
  // Public: authenticated users publish catalogue entries immediately.
  // Private: authenticated users create a suggestion for admin review.
  if (path === '/api/items' && method === 'POST') {
    const user = await getUser(req, env);
    if (!user) throw new HttpError(401, 'Log in to add or suggest an item');
    const item = cleanItem(await readBody(req));
    if (modeFor(env) === 'public') {
      const r = await env.DB.prepare(
        'INSERT INTO items (name, description, image_url, created_at, added_by_user_id, added_by, status) VALUES (?, ?, ?, ?, ?, ?, \'published\')'
      ).bind(item.name, item.description, item.image_url, now(), user.id, user.username).run();
      await saveTags(env, r.meta.last_row_id, item.tags);
      return json({ ok: true, mode: 'public', item: await getItem(env, r.meta.last_row_id) }, 201);
    }
    const r = await env.DB.prepare(
      'INSERT INTO item_suggestions (name, description, image_url, tags_json, suggested_by_user_id, suggested_by, status, created_at) VALUES (?, ?, ?, ?, ?, ?, \'pending\', ?)'
    ).bind(item.name, item.description, item.image_url, JSON.stringify(item.tags), user.id, user.username, now()).run();
    return json({ ok: true, mode: 'private', suggestion: true, id: r.meta.last_row_id }, 202);
  }

  // Ratings remain available to guests; logged-in users can edit their own rating.
  if ((m = path.match(/^\/api\/items\/(\d+)\/reviews$/)) && method === 'POST') {
    const user = await getUser(req, env);
    const { rating, text = '' } = await readBody(req);
    if (!Number.isInteger(rating) || rating < 1 || rating > 10) throw new HttpError(400, 'Rating must be an integer from 1 to 10');
    if (String(text).length > 2000) throw new HttpError(400, 'Review is too long (max 2000 characters)');
    if (!(await getItem(env, +m[1]))) throw new HttpError(404, 'Item not found');
    if (user) {
      await env.DB.prepare(
        `INSERT INTO reviews (item_id, user_id, author, rating, text, created_at, status)
         VALUES (?, ?, ?, ?, ?, ?, 'published')
         ON CONFLICT(item_id, user_id) WHERE user_id IS NOT NULL
         DO UPDATE SET rating = excluded.rating, text = excluded.text, created_at = excluded.created_at`
      ).bind(+m[1], user.id, user.username, rating, String(text).trim(), now()).run();
    } else {
      const h = await ipHash(req, env);
      const recent = await env.DB.prepare(
        'SELECT SUM(item_id = ?) AS same_item, COUNT(*) AS total FROM reviews WHERE user_id IS NULL AND ip_hash = ? AND created_at > ?'
      ).bind(+m[1], h, now() - 86400).first();
      if ((recent?.same_item ?? 0) > 0) throw new HttpError(429, 'You already reviewed this as a guest today. Log in to edit your review.');
      if ((recent?.total ?? 0) >= 30) throw new HttpError(429, 'Too many guest reviews today. Please log in.');
      await env.DB.prepare(
        "INSERT INTO reviews (item_id, user_id, author, rating, text, created_at, ip_hash, status) VALUES (?, NULL, 'Guest', ?, ?, ?, ?, 'published')"
      ).bind(+m[1], rating, String(text).trim(), now(), h).run();
    }
    return json({ ok: true }, 201);
  }
  if ((m = path.match(/^\/api\/items\/(\d+)\/reviews\/mine$/)) && method === 'DELETE') {
    const user = await getUser(req, env);
    if (!user) throw new HttpError(401, 'Log in first');
    await env.DB.prepare('DELETE FROM reviews WHERE item_id = ? AND user_id = ?').bind(+m[1], user.id).run();
    return json({ ok: true });
  }

  // Logged-in users can flag catalogue entries or reviews for moderator attention.
  if (path === '/api/reports' && method === 'POST') {
    const user = await getUser(req, env);
    if (!user) throw new HttpError(401, 'Log in to report content');
    const body = await readBody(req);
    const targetType = String(body.target_type || '');
    const targetId = Number(body.target_id);
    const reason = String(body.reason || '').trim();
    if (!['item', 'review'].includes(targetType) || !Number.isInteger(targetId) || targetId < 1) throw new HttpError(400, 'Choose valid content to report');
    if (!reason || reason.length > 500) throw new HttpError(400, 'Add a reason (max 500 characters)');
    const exists = targetType === 'item'
      ? await env.DB.prepare('SELECT id FROM items WHERE id = ?').bind(targetId).first()
      : await env.DB.prepare('SELECT id FROM reviews WHERE id = ?').bind(targetId).first();
    if (!exists) throw new HttpError(404, 'Content not found');
    const duplicate = await env.DB.prepare(
      "SELECT id FROM reports WHERE target_type = ? AND target_id = ? AND reporter_user_id = ? AND status = 'pending'"
    ).bind(targetType, targetId, user.id).first();
    if (duplicate) throw new HttpError(409, 'You already reported this content');
    await env.DB.prepare(
      "INSERT INTO reports (target_type, target_id, reporter_user_id, reporter, reason, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', ?)"
    ).bind(targetType, targetId, user.id, user.username, reason, now()).run();
    return json({ ok: true }, 201);
  }

  // Moderation and administration
  if (path.startsWith('/admin')) {
    requireAdmin(req, env);
    if (path === '/admin/ping' && method === 'GET') return json({ ok: true, ...publicConfig(env) });
    if (path === '/admin/user-reports' && method === 'GET') {
      const { results } = await env.DB.prepare(
        `SELECT r.id, r.reason, r.created_at, reporter.username AS reporter, target.username AS target
         FROM user_reports r JOIN users reporter ON reporter.id = r.reporter_id
         JOIN users target ON target.id = r.target_id WHERE r.status = 'pending'
         ORDER BY r.created_at ASC LIMIT 200`
      ).all();
      return json({ reports: results });
    }
    if ((m = path.match(/^\/admin\/user-reports\/(\d+)$/)) && method === 'PUT') {
      const id = +m[1];
      const report = await env.DB.prepare('SELECT * FROM user_reports WHERE id = ?').bind(id).first();
      if (!report) throw new HttpError(404, 'User report not found');
      if (report.status !== 'pending') throw new HttpError(409, 'Report already handled');
      const { action = '' } = await readBody(req);
      if (action === 'suspend') {
        await env.DB.batch([
          env.DB.prepare("UPDATE users SET status = 'suspended' WHERE id = ?").bind(report.target_id),
          env.DB.prepare("UPDATE user_reports SET status = 'actioned', reviewed_at = ? WHERE id = ?").bind(now(), id)
        ]);
        return json({ ok: true, status: 'actioned' });
      }
      if (action === 'dismiss') {
        await env.DB.prepare("UPDATE user_reports SET status = 'dismissed', reviewed_at = ? WHERE id = ?").bind(now(), id).run();
        return json({ ok: true, status: 'dismissed' });
      }
      throw new HttpError(400, 'Action must be suspend or dismiss');
    }
    if (path === '/admin/items' && method === 'GET') return json({ items: await listItems(env, true) });
    if (path === '/admin/items' && method === 'POST') {
      const it = cleanItem(await readBody(req));
      const r = await env.DB.prepare(
        "INSERT INTO items (name, description, image_url, created_at, added_by, status) VALUES (?, ?, ?, ?, 'Admin', 'published')"
      ).bind(it.name, it.description, it.image_url, now()).run();
      await saveTags(env, r.meta.last_row_id, it.tags);
      return json(await getItem(env, r.meta.last_row_id, true), 201);
    }
    if ((m = path.match(/^\/admin\/items\/(\d+)$/))) {
      const id = +m[1];
      if (!(await getItem(env, id, true))) throw new HttpError(404, 'Item not found');
      if (method === 'PUT') {
        const body = await readBody(req);
        const it = cleanItem(body, true);
        const keys = Object.keys(it).filter(k => k !== 'tags');
        if (body.status !== undefined) {
          if (!['published', 'hidden'].includes(body.status)) throw new HttpError(400, 'Invalid item status');
          it.status = body.status;
          keys.push('status');
        }
        if (!keys.length && it.tags === undefined) throw new HttpError(400, 'Nothing to update');
        if (keys.length) await env.DB.prepare(`UPDATE items SET ${keys.map(k => `${k} = ?`).join(', ')} WHERE id = ?`)
          .bind(...keys.map(k => it[k]), id).run();
        if (it.tags !== undefined) await saveTags(env, id, it.tags);
        return json(await getItem(env, id, true));
      }
      if (method === 'DELETE') {
        await env.DB.batch([
          env.DB.prepare('DELETE FROM reports WHERE (target_type = \'item\' AND target_id = ?) OR (target_type = \'review\' AND target_id IN (SELECT id FROM reviews WHERE item_id = ?))').bind(id, id),
          env.DB.prepare('DELETE FROM item_suggestions WHERE item_id = ?').bind(id),
          env.DB.prepare('DELETE FROM reviews WHERE item_id = ?').bind(id),
          env.DB.prepare('DELETE FROM item_tags WHERE item_id = ?').bind(id),
          env.DB.prepare('DELETE FROM items WHERE id = ?').bind(id),
        ]);
        return json({ ok: true });
      }
    }
    if (path === '/admin/reviews' && method === 'GET') {
      const status = url.searchParams.get('status') === 'published' ? 'published' : 'hidden';
      const { results } = await env.DB.prepare(
        'SELECT id, item_id, author, rating, text, status, created_at FROM reviews WHERE status = ? ORDER BY created_at DESC LIMIT 500'
      ).bind(status).all();
      return json({ reviews: results });
    }
    if ((m = path.match(/^\/admin\/reviews\/(\d+)$/))) {
      if (method === 'PUT') {
        const { status } = await readBody(req);
        if (!['published', 'hidden'].includes(status)) throw new HttpError(400, 'Review status must be published or hidden');
        const result = await env.DB.prepare('UPDATE reviews SET status = ? WHERE id = ?').bind(status, +m[1]).run();
        if (!result.meta.changes) throw new HttpError(404, 'Review not found');
        return json({ ok: true, status });
      }
      if (method === 'DELETE') {
        await env.DB.prepare('DELETE FROM reviews WHERE id = ?').bind(+m[1]).run();
        return json({ ok: true });
      }
    }
    if (path === '/admin/suggestions' && method === 'GET') {
      const { results } = await env.DB.prepare(
        "SELECT id, name, description, image_url, tags_json, suggested_by, status, created_at FROM item_suggestions WHERE status = 'pending' ORDER BY created_at ASC"
      ).all();
      return json({ suggestions: results.map(x => ({ ...x, tags: JSON.parse(x.tags_json || '[]') })) });
    }
    if ((m = path.match(/^\/admin\/suggestions\/(\d+)$/)) && method === 'PUT') {
      const id = +m[1];
      const suggestion = await env.DB.prepare('SELECT * FROM item_suggestions WHERE id = ?').bind(id).first();
      if (!suggestion) throw new HttpError(404, 'Suggestion not found');
      if (suggestion.status !== 'pending') throw new HttpError(409, 'Suggestion has already been reviewed');
      const { action = '' } = await readBody(req);
      if (action === 'reject') {
        await env.DB.prepare("UPDATE item_suggestions SET status = 'rejected', reviewed_at = ?, reviewed_by = 'Admin' WHERE id = ?")
          .bind(now(), id).run();
        return json({ ok: true, status: 'rejected' });
      }
      if (action !== 'approve') throw new HttpError(400, 'Action must be approve or reject');
      const r = await env.DB.prepare(
        "INSERT INTO items (name, description, image_url, created_at, added_by_user_id, added_by, status) VALUES (?, ?, ?, ?, ?, ?, 'published')"
      ).bind(suggestion.name, suggestion.description, suggestion.image_url, now(), suggestion.suggested_by_user_id, suggestion.suggested_by).run();
      const tags = cleanTags(JSON.parse(suggestion.tags_json || '[]'));
      await saveTags(env, r.meta.last_row_id, tags);
      await env.DB.prepare(
        "UPDATE item_suggestions SET status = 'approved', reviewed_at = ?, reviewed_by = 'Admin', item_id = ? WHERE id = ?"
      ).bind(now(), r.meta.last_row_id, id).run();
      return json({ ok: true, status: 'approved', item: await getItem(env, r.meta.last_row_id) }, 201);
    }
    if (path === '/admin/reports' && method === 'GET') {
      const { results } = await env.DB.prepare(
        "SELECT id, target_type, target_id, reporter, reason, status, created_at FROM reports WHERE status = 'pending' ORDER BY created_at ASC"
      ).all();
      return json({ reports: results });
    }
    if ((m = path.match(/^\/admin\/reports\/(\d+)$/)) && method === 'PUT') {
      const id = +m[1];
      const report = await env.DB.prepare('SELECT * FROM reports WHERE id = ?').bind(id).first();
      if (!report) throw new HttpError(404, 'Report not found');
      if (report.status !== 'pending') throw new HttpError(409, 'Report has already been handled');
      const { action = '' } = await readBody(req);
      if (action === 'hide') {
        if (report.target_type === 'item') {
          await env.DB.prepare("UPDATE items SET status = 'hidden' WHERE id = ?").bind(report.target_id).run();
        } else {
          await env.DB.prepare("UPDATE reviews SET status = 'hidden' WHERE id = ?").bind(report.target_id).run();
        }
        await env.DB.prepare("UPDATE reports SET status = 'actioned', reviewed_at = ? WHERE id = ?").bind(now(), id).run();
        return json({ ok: true, status: 'actioned' });
      }
      if (action === 'dismiss') {
        await env.DB.prepare("UPDATE reports SET status = 'dismissed', reviewed_at = ? WHERE id = ?").bind(now(), id).run();
        return json({ ok: true, status: 'dismissed' });
      }
      throw new HttpError(400, 'Action must be hide or dismiss');
    }
  }
  throw new HttpError(404, 'Not found');
}

export default {
  async fetch(req, env) {
    try { return await handle(req, env); }
    catch (e) {
      if (e instanceof HttpError) return json({ error: e.message }, e.status);
      console.error(e);
      return json({ error: 'Server error' }, 500);
    }
  },
};

// ---------- responsive admin dashboard ----------
const PANEL_HTML = String.raw`<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ratings · Admin</title><style>
:root{color-scheme:dark;font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,sans-serif;background:#0d1020;color:#eef0ff;font-synthesis:none}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(800px 400px at 0% 0%,#29255b 0%,transparent 65%),#0d1020;min-height:100vh;padding:28px 16px}
.wrap{max-width:1040px;margin:auto}.hero{display:flex;justify-content:space-between;gap:16px;align-items:center;margin-bottom:24px}.eyebrow{color:#a7a6ff;text-transform:uppercase;letter-spacing:.14em;font-size:11px;font-weight:800}
h1{font-size:clamp(28px,5vw,42px);letter-spacing:-.04em;margin:6px 0}h2{font-size:18px;margin:0 0 14px}.muted{color:#a7abc7;font-size:13px}.pill{border:1px solid #45476e;background:#1a1d36;padding:7px 11px;border-radius:999px;font-size:12px;color:#d8d9ff}
.panel,.card{background:#171a30;border:1px solid #2d3151;border-radius:20px;padding:18px;box-shadow:0 18px 55px #05071145}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.wide{grid-column:1/-1}.tabs{display:flex;gap:8px;flex-wrap:wrap;margin:18px 0}.tab,button{border:0;border-radius:12px;padding:10px 14px;font:inherit;font-weight:700;cursor:pointer}.tab{background:#1d203b;color:#c4c7e8}.tab.active,button.primary{background:linear-gradient(135deg,#8b7cff,#5f69e8);color:white}.tab.active{box-shadow:0 6px 22px #6860e955}button{background:#292d4c;color:#e7e9ff;margin:4px 4px 4px 0}button.danger{background:#592d44;color:#ffcedd}button.good{background:#204b49;color:#bff8e9}
input,textarea{width:100%;padding:12px 13px;background:#0f1225;color:#f3f4ff;border:1px solid #363a5b;border-radius:12px;font:inherit;margin:5px 0 10px;outline:none}input:focus,textarea:focus{border-color:#8b7cff}textarea{min-height:90px;resize:vertical}.row{display:flex;gap:10px}.row>*{flex:1}.card{padding:15px;margin:10px 0;box-shadow:none}.card img{width:100%;max-height:180px;object-fit:cover;border-radius:12px;margin-bottom:10px}.tag{display:inline-block;border:1px solid #45476e;border-radius:999px;padding:4px 8px;color:#c8caff;font-size:11px;margin:2px}.itemtitle{font-weight:800;font-size:17px}.section[hidden],#app[hidden],#login[hidden]{display:none}.empty{padding:20px;text-align:center;color:#a7abc7;border:1px dashed #45476e;border-radius:14px}.error{color:#ff9baa;min-height:18px}.meta{font-size:12px;color:#a7abc7;margin:6px 0 12px}.actions{display:flex;flex-wrap:wrap;gap:4px}.suggestion,.report{border-top:1px solid #303453;padding:14px 0}.suggestion:first-child,.report:first-child{border-top:0}.report strong{color:#ffcb8c}.badge{font-size:11px;padding:4px 8px;border-radius:8px;background:#34304e;color:#d9d3ff}
@media(max-width:700px){body{padding:18px 12px}.grid{grid-template-columns:1fr}.wide{grid-column:auto}.hero{align-items:flex-start;flex-direction:column}.row{display:block}}
</style></head><body><div class="wrap">
<header class="hero"><div><div class="eyebrow">RATINGS / CONTROL ROOM</div><h1>Keep the catalogue tidy.</h1><div class="muted">Review submissions, handle reports, and manage published items.</div></div><div class="pill" id="serverMode">SERVER · LOADING</div></header>
<section class="panel" id="login"><h2>Admin access</h2><p class="muted">Enter this server's admin token. It stays in this browser tab's session.</p><input id="token" type="password" placeholder="Admin token" autocomplete="off"><button class="primary" id="go">Unlock dashboard</button><div class="error" id="err"></div></section>
<main id="app" hidden>
<nav class="tabs"><button class="tab active" data-tab="items">Catalogue</button><button class="tab" data-tab="suggestions">Suggestions <span id="suggestCount"></span></button><button class="tab" data-tab="reports">Reports <span id="reportCount"></span></button><button class="tab" data-tab="accountReports">Account reports <span id="accountReportCount"></span></button></nav>
<section class="section" id="items">
<div class="grid"><div class="panel"><h2 id="formTitle">Add catalogue item</h2><form id="form"><input id="name" placeholder="Name" maxlength="100" required><input id="image" placeholder="Image URL (https://...)" type="url"><textarea id="desc" placeholder="Description" maxlength="2000"></textarea><input id="tags" placeholder="Tags, comma separated (max 8)"><div class="actions"><button class="primary">Save item</button><button type="button" id="cancel">Cancel edit</button></div></form></div><div class="panel"><h2>Moderation notes</h2><p class="muted">Public servers publish logged-in user submissions immediately. Private servers collect suggestions here until an admin approves them.</p><p class="muted">Reports can hide an item or review from public view. Hidden items can be restored from the catalogue list.</p></div><div class="panel wide"><h2>Published and hidden items</h2><div id="list"></div></div></div>
</section>
<section class="section" id="suggestions" hidden><div class="panel"><h2>Pending suggestions</h2><div class="muted">Approve a suggestion to publish it. The original contributor remains credited.</div><div id="suggestionList"></div></div></section>
<section class="section" id="reports" hidden><div class="panel"><h2>Content reports</h2><div class="muted">Hide reported content or dismiss a report. Hiding does not permanently delete content.</div><div id="reportList"></div><h2 style="margin-top:24px">Hidden reviews</h2><div id="hiddenReviewList"></div></div></section>
<section class="section" id="accountReports" hidden><div class="panel"><h2>Account reports</h2><div class="muted">Review reports submitted about user accounts. Suspending an account disables sign-in and authenticated requests.</div><div id="accountReportList"></div></div></section>
</main></div>
<script>
var token=sessionStorage.getItem('ratings_admin_token')||'',editId=null;function $(id){return document.getElementById(id)}
function el(tag,props,kids){var e=document.createElement(tag);Object.assign(e,props||{});(kids||[]).forEach(function(k){e.append(k)});return e}
function btn(label,fn,cls){return el('button',{textContent:label,className:cls||'',onclick:fn,type:'button'})}
async function api(method,path,body){var r=await fetch(path,{method:method,headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});var j=await r.json().catch(function(){return {}});if(!r.ok)throw new Error(j.error||('HTTP '+r.status));return j}
async function unlock(){token=$('token').value||token;try{var p=await api('GET','/admin/ping');sessionStorage.setItem('ratings_admin_token',token);$('login').hidden=true;$('app').hidden=false;$('serverMode').textContent='SERVER · '+p.mode.toUpperCase()+' · '+p.name;await loadAll()}catch(e){$('err').textContent=e.message}}
function showTab(name){document.querySelectorAll('.section').forEach(function(s){s.hidden=s.id!==name});document.querySelectorAll('.tab').forEach(function(b){b.classList.toggle('active',b.dataset.tab===name)})}
document.querySelectorAll('.tab').forEach(function(b){b.onclick=function(){showTab(b.dataset.tab)}});
async function loadAll(){await Promise.all([loadItems(),loadSuggestions(),loadReports(),loadHiddenReviews(),loadAccountReports()])}
async function loadItems(){var data=await api('GET','/admin/items'),box=$('list');box.textContent='';if(!data.items.length){box.append(el('div',{className:'empty',textContent:'No catalogue items yet.'}));return}data.items.forEach(function(it){var c=el('article',{className:'card'});if(it.image_url)c.append(el('img',{src:it.image_url,alt:''}));c.append(el('div',{className:'itemtitle',textContent:it.name}),el('div',{className:'meta',textContent:'Added by '+(it.added_by||'Admin')+' · '+(it.review_count||0)+' reviews · '+it.status}));if(it.description)c.append(el('p',{className:'muted',textContent:it.description}));(it.tags||[]).forEach(function(t){c.append(el('span',{className:'tag',textContent:t}))});var actions=el('div',{className:'actions'});actions.append(btn('Edit',function(){startEdit(it)}));actions.append(btn(it.status==='hidden'?'Restore':'Hide',async function(){try{await api('PUT','/admin/items/'+it.id,{status:it.status==='hidden'?'published':'hidden'});await loadItems()}catch(e){alert(e.message)}},'ghost'));actions.append(btn('Delete',async function(){if(!confirm('Permanently delete this item and its reviews?'))return;try{await api('DELETE','/admin/items/'+it.id);await loadItems()}catch(e){alert(e.message)}},'danger'));c.append(actions);box.append(c)})}
function startEdit(it){editId=it.id;$('name').value=it.name;$('image').value=it.image_url||'';$('desc').value=it.description||'';$('tags').value=(it.tags||[]).join(', ');$('formTitle').textContent='Edit item #'+it.id;showTab('items');window.scrollTo(0,0)}
function resetForm() {editId=null;$('form').reset();$('formTitle').textContent='Add catalogue item'}
async function loadSuggestions(){var data=await api('GET','/admin/suggestions'),box=$('suggestionList');box.textContent='';$('suggestCount').textContent=data.suggestions.length?'('+data.suggestions.length+')':'';if(!data.suggestions.length){box.append(el('div',{className:'empty',textContent:'No pending suggestions.'}));return}data.suggestions.forEach(function(s){var c=el('article',{className:'suggestion'});c.append(el('div',{className:'itemtitle',textContent:s.name}),el('div',{className:'meta',textContent:'Suggested by '+s.suggested_by+' · '+new Date(s.created_at*1000).toLocaleString()}));if(s.description)c.append(el('p',{className:'muted',textContent:s.description}));(s.tags||[]).forEach(function(t){c.append(el('span',{className:'tag',textContent:t}))});var row=el('div',{className:'actions'});row.append(btn('Approve & publish',async function(){try{await api('PUT','/admin/suggestions/'+s.id,{action:'approve'});await loadAll()}catch(e){alert(e.message)}},'good'));row.append(btn('Reject',async function(){try{await api('PUT','/admin/suggestions/'+s.id,{action:'reject'});await loadSuggestions()}catch(e){alert(e.message)}},'danger'));c.append(row);box.append(c)})}
async function loadReports(){var data=await api('GET','/admin/reports'),box=$('reportList');box.textContent='';$('reportCount').textContent=data.reports.length?'('+data.reports.length+')':'';if(!data.reports.length){box.append(el('div',{className:'empty',textContent:'No pending reports.'}));return}data.reports.forEach(function(r){var c=el('article',{className:'report'});c.append(el('div',{className:'itemtitle',textContent:r.target_type.toUpperCase()+' #'+r.target_id}),el('div',{className:'meta',textContent:'Reported by '+r.reporter+' · '+new Date(r.created_at*1000).toLocaleString()}),el('p',{className:'muted',textContent:r.reason}));var row=el('div',{className:'actions'});row.append(btn('Hide content',async function(){try{await api('PUT','/admin/reports/'+r.id,{action:'hide'});await loadAll()}catch(e){alert(e.message)}},'danger'));row.append(btn('Dismiss',async function(){try{await api('PUT','/admin/reports/'+r.id,{action:'dismiss'});await loadReports()}catch(e){alert(e.message)}}));c.append(row);box.append(c)})}
async function loadAccountReports(){var data=await api('GET','/admin/user-reports'),box=$('accountReportList');box.textContent='';$('accountReportCount').textContent=data.reports.length?'('+data.reports.length+')':'';if(!data.reports.length){box.append(el('div',{className:'empty',textContent:'No pending account reports.'}));return}data.reports.forEach(function(r){var c=el('article',{className:'report'});c.append(el('div',{className:'itemtitle',textContent:'@'+r.target}),el('div',{className:'meta',textContent:'Reported by '+r.reporter+' · '+new Date(r.created_at*1000).toLocaleString()}),el('p',{className:'muted',textContent:r.reason}));var row=el('div',{className:'actions'});row.append(btn('Suspend account',async function(){if(!confirm('Suspend @'+r.target+'? The account will no longer be able to sign in or use authenticated features.'))return;try{await api('PUT','/admin/user-reports/'+r.id,{action:'suspend'});await loadAll()}catch(e){alert(e.message)}},'danger'));row.append(btn('Dismiss',async function(){try{await api('PUT','/admin/user-reports/'+r.id,{action:'dismiss'});await loadAccountReports()}catch(e){alert(e.message)}}));c.append(row);box.append(c)})}
async function loadHiddenReviews(){var data=await api('GET','/admin/reviews?status=hidden'),box=$('hiddenReviewList');box.textContent='';if(!data.reviews.length){box.append(el('div',{className:'empty',textContent:'No hidden reviews.'}));return}data.reviews.forEach(function(r){var c=el('article',{className:'suggestion'});c.append(el('div',{className:'itemtitle',textContent:'Item #'+r.item_id+' · '+r.author+' · '+r.rating+'/10'}));if(r.text)c.append(el('p',{className:'muted',textContent:r.text}));var row=el('div',{className:'actions'});row.append(btn('Restore review',async function(){try{await api('PUT','/admin/reviews/'+r.id,{status:'published'});await loadAll()}catch(e){alert(e.message)}},'good'));row.append(btn('Delete review',async function(){if(!confirm('Permanently delete this review?'))return;try{await api('DELETE','/admin/reviews/'+r.id);await loadAll()}catch(e){alert(e.message)}},'danger'));c.append(row);box.append(c)})}
$('go').onclick=unlock;$('cancel').onclick=resetForm;
$('form').onsubmit=async function(e){e.preventDefault();var b={name:$('name').value,image_url:$('image').value,description:$('desc').value,tags:$('tags').value.split(',').map(function(x){return x.trim()}).filter(Boolean)};try{if(editId)await api('PUT','/admin/items/'+editId,b);else await api('POST','/admin/items',b);resetForm();await loadItems()}catch(x){alert(x.message)}};
if(token){$('token').value=token;unlock()}
</script></body></html>`;

if (typeof globalThis !== 'undefined') {
  // The panel route is resolved in handle() after module initialization.
}
