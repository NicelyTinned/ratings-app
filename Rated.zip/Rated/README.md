# Rated

Rated is a ratings and reviews catalogue with an Android client, a browser client, public and private servers, and optional social features.

## Android client

- Kotlin and Jetpack Compose application in `app/`.
- App name: **Rated**.
- Existing Android application ID retained as `com.example.ratingapp` so earlier installations can be upgraded.
- Includes catalogue browsing, ratings, reviews, tags, saved custom servers, profiles, follows, blocks, and text-only direct messages.

## Social features

- Profiles include a display name, short bio, optional HTTPS avatar, published entries, and published reviews.
- Users can follow/unfollow accounts and view follower/following lists.
- Users can block/unblock accounts. Blocking removes both follow links and prevents profile and message access between the two accounts.
- Users can report accounts to server moderators.
- Direct messages are text-only, require mutual follows, are limited to 2,000 characters per message and 100 messages per sender per day.
- Server administrators can dismiss account reports or suspend accounts from `/panel`.
- Server administrators operate the D1 database and can access stored message data. Users should not send passwords or sensitive personal information through DMs.

## Server files

- `worker/public-worker.js` — public community Worker.
- `worker/worker.js` — private/custom server Worker.
- `worker/schema.sql` — base D1 schema.
- `worker/migrations/001_add_ip_hash.sql` — legacy-only migration if `reviews.ip_hash` is missing.
- `worker/migrations/002_community_features.sql` — adds contributor attribution, suggestions, and moderation status fields.
- `worker/migrations/003_profiles_social.sql` — adds profiles, follows, blocks, direct messages, and account reports.

### New D1 database

Run the base schema and migrations in this order:

```bash
wrangler d1 execute rated-db --remote --file=worker/schema.sql
wrangler d1 execute rated-db --remote --file=worker/migrations/002_community_features.sql
wrangler d1 execute rated-db --remote --file=worker/migrations/003_profiles_social.sql
```

Migration 001 is not required for a new database because the supplied base schema already contains `reviews.ip_hash`. Do not run migrations 002 or 003 twice. They add columns using `ALTER TABLE`.

### Existing D1 database

Back up the database first. Keep the existing database and Worker binding. Apply only migrations that have not already been run. If the database predates `reviews.ip_hash`, run migration 001 before the community migration. Then deploy the updated Worker script.

### Private server settings

Use `worker/worker.js` and configure:

- D1 binding: `DB`
- Variable: `SERVER_MODE=private`
- Variable: `SERVER_NAME=Your Server Name`
- Secret: `JWT_SECRET`
- Secret: `ADMIN_TOKEN`

Open `https://YOUR-WORKER-URL/panel` to manage entries, suggestions, content reports, hidden reviews, and account reports.

## API overview

- `GET /api/config`, `GET /api/items`, `GET /api/items/:id`, `GET /api/tags`
- `POST /api/signup`, `POST /api/login`
- `POST /api/items` — authenticated; instant publish in public mode, suggestion queue in private mode
- `POST /api/items/:id/reviews`, `DELETE /api/items/:id/reviews/mine`
- `PUT /api/me/profile`, `GET /api/users/:username`
- `GET /api/users/:username/followers`, `GET /api/users/:username/following`
- `POST|DELETE /api/users/:username/follow`
- `POST|DELETE /api/users/:username/block`
- `POST /api/users/:username/report`, `GET /api/me/blocks`
- `GET /api/messages`, `GET|POST /api/messages/:username`
- `GET /admin/user-reports`, `PUT /admin/user-reports/:id`

## Static website

The separate `Rated-Website.zip` has these routes:

- `/` — landing page and the Android download link.
- `/app/` — browser client for desktop and non-Android users.
- `/docs/` — in-depth private/custom server tutorial.

The website checks the latest published GitHub release for an APK from `NicelyTinned/ratings-app`. If an APK asset is found, the button links directly to that asset; otherwise it opens the official latest release page.

Repository: https://github.com/NicelyTinned/ratings-app

## Android build workflow

`.github/workflows/android.yml` runs only for a published GitHub release or a manual workflow dispatch. A manual run uploads the APK as a workflow artifact. A release run attaches the APK to the release.
