package com.example.ratingapp

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(message: String, val code: Int = 0) : Exception(message)

/** "my-worker.me.workers.dev/" -> "https://my-worker.me.workers.dev" (null if invalid) */
fun normalizeUrl(raw: String): String? {
    var s = raw.trim()
    if (s.isEmpty()) return null
    if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "https://$s"
    return s.toHttpUrlOrNull()?.toString()?.trimEnd('/')
}

class Api(private val baseUrl: String, private val token: () -> String?) {
    private val client = sharedClient
    private val json = Json { ignoreUnknownKeys = true }

    companion object {
        private val sharedClient: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .writeTimeout(20, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build()
        }
    }

    private suspend fun call(verb: String, path: String, body: JsonObject? = null): String =
        withContext(Dispatchers.IO) {
            val req = Request.Builder().url(baseUrl + path).apply {
                token()?.let { header("Authorization", "Bearer $it") }
                if (verb == "GET") get()
                else method(verb, (body?.toString() ?: "{}").toRequestBody("application/json".toMediaType()))
            }.build()
            try {
                client.newCall(req).execute().use { r ->
                    val text = r.body?.string().orEmpty()
                    if (!r.isSuccessful) {
                        val msg = runCatching {
                            json.parseToJsonElement(text).jsonObject["error"]?.jsonPrimitive?.content
                        }.getOrNull()
                        throw ApiException(msg ?: "Server error (${r.code})", r.code)
                    }
                    text
                }
            } catch (e: IOException) {
                throw ApiException("Can't reach server: ${e.message}")
            }
        }

    suspend fun ping() {
        val response = try { call("GET", "/") } catch (e: ApiException) {
            throw ApiException("That doesn't look like the rating server")
        }
        if (!response.contains("rating-worker")) throw ApiException("That doesn't look like the rating server")
    }

    suspend fun config() = json.decodeFromString<ServerConfig>(call("GET", "/api/config"))

    private fun creds(u: String, p: String) = buildJsonObject { put("username", u); put("password", p) }
    suspend fun login(u: String, p: String) =
        json.decodeFromString<AuthResponse>(call("POST", "/api/login", creds(u, p)))
    suspend fun signup(u: String, p: String) =
        json.decodeFromString<AuthResponse>(call("POST", "/api/signup", creds(u, p)))

    suspend fun items() = json.decodeFromString<ItemsResponse>(call("GET", "/api/items")).items
    suspend fun detail(id: Int) = json.decodeFromString<ItemDetail>(call("GET", "/api/items/$id"))
    suspend fun deleteMyReview(id: Int) { call("DELETE", "/api/items/$id/reviews/mine") }
    suspend fun postReview(id: Int, rating: Int, text: String) {
        call("POST", "/api/items/$id/reviews", buildJsonObject { put("rating", rating); put("text", text) })
    }

    suspend fun submitItem(name: String, description: String, imageUrl: String, tags: List<String>): SubmissionResult {
        val body = buildJsonObject {
            put("name", name)
            put("description", description)
            put("image_url", imageUrl)
            putJsonArray("tags") { tags.forEach { add(JsonPrimitive(it)) } }
        }
        val response = json.parseToJsonElement(call("POST", "/api/items", body)).jsonObject
        val isSuggestion = response["suggestion"]?.jsonPrimitive?.booleanOrNull == true
        return if (isSuggestion) SubmissionResult.Suggested else SubmissionResult.Published
    }

    suspend fun report(targetType: String, targetId: Int, reason: String) {
        call("POST", "/api/reports", buildJsonObject {
            put("target_type", targetType)
            put("target_id", targetId)
            put("reason", reason)
        })
    }

    suspend fun profile(username: String) = json.decodeFromString<ProfileResponse>(call("GET", "/api/users/$username"))

    suspend fun updateProfile(displayName: String, bio: String, avatarUrl: String) {
        call("PUT", "/api/me/profile", buildJsonObject {
            put("display_name", displayName)
            put("bio", bio)
            put("avatar_url", avatarUrl)
        })
    }

    suspend fun follow(username: String) { call("POST", "/api/users/$username/follow") }
    suspend fun unfollow(username: String) { call("DELETE", "/api/users/$username/follow") }
    suspend fun block(username: String) { call("POST", "/api/users/$username/block") }
    suspend fun unblock(username: String) { call("DELETE", "/api/users/$username/block") }
    suspend fun reportUser(username: String, reason: String) {
        call("POST", "/api/users/$username/report", buildJsonObject { put("reason", reason) })
    }
    suspend fun relationshipUsers(username: String, type: String) =
        json.decodeFromString<ProfileUsersResponse>(call("GET", "/api/users/$username/$type")).users
    suspend fun blockedUsers() = json.decodeFromString<ProfileUsersResponse>(call("GET", "/api/me/blocks")).users
    suspend fun conversations() = json.decodeFromString<MessageThreadsResponse>(call("GET", "/api/messages")).conversations
    suspend fun messages(username: String) = json.decodeFromString<DirectMessagesResponse>(call("GET", "/api/messages/$username"))
    suspend fun sendMessage(username: String, body: String) {
        call("POST", "/api/messages/$username", buildJsonObject { put("body", body) })
    }
}
