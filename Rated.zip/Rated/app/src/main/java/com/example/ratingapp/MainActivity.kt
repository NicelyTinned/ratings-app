package com.example.ratingapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

private val RatedColors = darkColorScheme(
    primary = Color(0xFFB7AAFF), onPrimary = Color(0xFF1D1740),
    primaryContainer = Color(0xFF403A70), onPrimaryContainer = Color(0xFFE7E2FF),
    secondary = Color(0xFFA9B8E8), onSecondary = Color(0xFF18213F),
    secondaryContainer = Color(0xFF30395C), onSecondaryContainer = Color(0xFFDCE3FF),
    tertiary = Color(0xFFFFC857), onTertiary = Color(0xFF30200A),
    background = Color(0xFF0B0D18), onBackground = Color(0xFFF5F3FF),
    surface = Color(0xFF171B2E), onSurface = Color(0xFFF5F3FF),
    surfaceVariant = Color(0xFF252A42), onSurfaceVariant = Color(0xFFADB4D0),
    outline = Color(0xFF626A8B), outlineVariant = Color(0xFF3C435F),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 13, 24)
        window.navigationBarColor = android.graphics.Color.rgb(11, 13, 24)
        setContent {
            MaterialTheme(
                colorScheme = RatedColors,
                shapes = Shapes(
                    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(9.dp),
                    small = androidx.compose.foundation.shape.RoundedCornerShape(13.dp),
                    medium = androidx.compose.foundation.shape.RoundedCornerShape(17.dp),
                    large = androidx.compose.foundation.shape.RoundedCornerShape(23.dp),
                    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(29.dp),
                ),
            ) {
                Surface(Modifier.fillMaxSize(), color = RatedColors.background) {
                    val vm: AppVM = viewModel()
                    BackHandler(enabled = vm.canGoBack) { vm.back() }
                    when (val s = vm.screen) {
                        Screen.Setup -> SetupScreen(vm)
                        Screen.Home -> HomeScreen(vm)
                        Screen.Auth -> AuthScreen(vm)
                        Screen.AddItem -> AddItemScreen(vm)
                        is Screen.Detail -> DetailScreen(vm, s.id)
                        Screen.ProfileSearch -> ProfileSearchScreen(vm)
                        is Screen.Profile -> ProfileScreen(vm, s.username)
                        Screen.ProfileEdit -> ProfileEditScreen(vm)
                        is Screen.ProfileList -> ProfileListScreen(vm, s.username, s.listType)
                        Screen.Messages -> MessagesScreen(vm)
                        is Screen.Chat -> ChatScreen(vm, s.username)
                        Screen.BlockedUsers -> BlockedUsersScreen(vm)
                    }
                }
            }
        }
    }
}
