package com.example.ratingapp

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Item(
    val id: Int,
    val name: String,
    val description: String = "",
    @SerialName("image_url") val imageUrl: String = "",
    @SerialName("avg_rating") val avgRating: Double = 0.0,
    @SerialName("review_count") val reviewCount: Int = 0,
    @SerialName("added_by") val addedBy: String = "Admin",
    val tags: List<String> = emptyList(),
    val status: String = "published",
)

@Serializable
data class Review(
    val id: Int,
    val author: String,
    val rating: Int,
    val text: String = "",
    @SerialName("created_at") val createdAt: Long = 0,
)

@Serializable data class ItemsResponse(val items: List<Item>)
@Serializable data class MyReview(val id: Int, val rating: Int, val text: String = "")
@Serializable
data class ItemDetail(
    val item: Item,
    val reviews: List<Review>,
    @SerialName("my_review") val myReview: MyReview? = null,
)

@Serializable
data class ServerConfig(
    val name: String = "Ratings",
    val mode: String = "private",
    @SerialName("item_submission") val itemSubmission: String = "approval",
    @SerialName("login_required_to_add") val loginRequiredToAdd: Boolean = true,
)

data class SavedServer(val name: String, val url: String)

enum class Sort(val label: String) { Newest("Newest"), Top("Top rated"), Popular("Most reviewed") }
@Serializable data class AuthResponse(val token: String, val username: String)
enum class SubmissionResult { Published, Suggested }

@Serializable
data class ProfileInfo(
    val username: String,
    @SerialName("display_name") val displayName: String = "",
    val bio: String = "",
    @SerialName("avatar_url") val avatarUrl: String = "",
    @SerialName("created_at") val createdAt: Long = 0,
    @SerialName("follower_count") val followerCount: Int = 0,
    @SerialName("following_count") val followingCount: Int = 0,
    @SerialName("entry_count") val entryCount: Int = 0,
    @SerialName("review_count") val reviewCount: Int = 0,
    @SerialName("is_following") val isFollowing: Boolean = false,
    @SerialName("follows_you") val followsYou: Boolean = false,
    @SerialName("is_self") val isSelf: Boolean = false,
    @SerialName("can_message") val canMessage: Boolean = false,
)

@Serializable
data class ProfileEntry(
    val id: Int,
    val name: String,
    val description: String = "",
    @SerialName("image_url") val imageUrl: String = "",
    @SerialName("created_at") val createdAt: Long = 0,
)

@Serializable
data class ProfileReview(
    val id: Int,
    @SerialName("item_id") val itemId: Int,
    @SerialName("item_name") val itemName: String,
    val rating: Int,
    val text: String = "",
    @SerialName("created_at") val createdAt: Long = 0,
)

@Serializable
data class ProfileResponse(
    val profile: ProfileInfo,
    val entries: List<ProfileEntry> = emptyList(),
    val reviews: List<ProfileReview> = emptyList(),
)

@Serializable data class ProfileUser(val username: String, @SerialName("display_name") val displayName: String = "")
@Serializable data class ProfileUsersResponse(val users: List<ProfileUser>)

@Serializable
data class MessageThread(
    val username: String,
    @SerialName("display_name") val displayName: String = "",
    @SerialName("last_message") val lastMessage: String = "",
    @SerialName("last_message_at") val lastMessageAt: Long = 0,
    @SerialName("unread_count") val unreadCount: Int = 0,
)
@Serializable data class MessageThreadsResponse(val conversations: List<MessageThread>)

@Serializable
data class DirectMessage(
    val id: Int,
    @SerialName("sender_id") val senderId: Int,
    @SerialName("recipient_id") val recipientId: Int,
    val body: String,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("read_at") val readAt: Long? = null,
    val mine: Boolean = false,
)
@Serializable data class DirectMessagesResponse(val username: String, val messages: List<DirectMessage>)

sealed interface Screen {
    data object Setup : Screen
    data object Home : Screen
    data object Auth : Screen
    data object AddItem : Screen
    data class Detail(val id: Int) : Screen
    data object ProfileSearch : Screen
    data class Profile(val username: String) : Screen
    data object ProfileEdit : Screen
    data class ProfileList(val username: String, val listType: String) : Screen
    data object Messages : Screen
    data class Chat(val username: String) : Screen
    data object BlockedUsers : Screen
}
