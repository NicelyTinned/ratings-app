-- Only needed if you deployed the first version of this project (fresh installs already have the column):
--   npx wrangler d1 execute rating-db --remote --file=migrations/001_add_ip_hash.sql
ALTER TABLE reviews ADD COLUMN ip_hash TEXT;
