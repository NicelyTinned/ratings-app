// =====================================================================
// Rating app backend - ONE FILE: paste this whole file into the Cloudflare
// dashboard editor ("Edit code"). Needs: D1 binding named DB, and secrets
// JWT_SECRET and ADMIN_TOKEN. Also serves the admin page at /panel.
// =====================================================================
// Rating app backend — Cloudflare Worker + D1
// Secrets required: JWT_SECRET, ADMIN_TOKEN

// Increase security / decrease CPU time by changing this BEFORE anyone signs up (existing hashes would stop working).
const PBKDF2_ITERATIONS = 100000;

const enc = new TextEncoder();
const dec = new TextDecoder();

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-headers': 'authorization, content-type',
  'access-control-allow-methods': 'GET, POST, PUT, DELETE, OPTIONS',
};
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', ...CORS },
  });

// ---------- crypto helpers ----------
const b64u = (buf) =>
  btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = (s) =>
  Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), (c) => c.charCodeAt(0));

const hmacKey = (secret) =>
  crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);

async function signToken(payload, secret) {
  const body = b64u(enc.encode(JSON.stringify(payload)));
  const sig = await crypto.subtle.sign('HMAC', await hmacKey(secret), enc.encode(body));
  return `${body}.${b64u(sig)}`;
}
async function verifyToken(token, secret) {
  try {
    const [body, sig] = token.split('.');
    if (!body || !sig) return null;
    const ok = await crypto.subtle.verify('HMAC', await hmacKey(secret), unb64u(sig), enc.encode(body));
    if (!ok) return null;
    const p = JSON.parse(dec.decode(unb64u(body)));
    return p.exp > Date.now() / 1000 ? p : null;
  } catch { return null; }
}

async function pbkdf2(password, salt) {
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' }, key, 256);
  return b64u(bits);
}
async function hashPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return `${b64u(salt)}:${await pbkdf2(password, salt)}`;
}
async function checkPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  return safeEqual(await pbkdf2(password, unb64u(salt)), hash);
}
function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

// ---------- auth helpers ----------
async function getUser(req, env) {
  const h = req.headers.get('authorization');
  if (!h || !h.startsWith('Bearer ')) return null; // guest
  const p = await verifyToken(h.slice(7), env.JWT_SECRET);
  if (!p) throw new HttpError(401, 'Session expired, please log in again');
  return { id: p.uid, username: p.name };
}
function requireAdmin(req, env) {
  const h = req.headers.get('authorization') || '';
  if (!env.ADMIN_TOKEN || !h.startsWith('Bearer ') || !safeEqual(h.slice(7), env.ADMIN_TOKEN))
    throw new HttpError(403, 'Admin token required');
}
const authResponse = async (env, id, username) =>
  json({
    token: await signToken({ uid: id, name: username, exp: Math.floor(Date.now() / 1000) + 30 * 86400 }, env.JWT_SECRET),
    username,
  });

// ---------- validation ----------
async function readBody(req) {
  try { return await req.json(); } catch { throw new HttpError(400, 'Invalid JSON body'); }
}
function cleanItem(b, partial) {
  const out = {};
  if (!partial || b.name !== undefined) {
    const name = String(b.name ?? '').trim();
    if (!name || name.length > 100) throw new HttpError(400, 'name is required (max 100 chars)');
    out.name = name;
  }
  if (!partial || b.description !== undefined) {
    const d = String(b.description ?? '').trim();
    if (d.length > 2000) throw new HttpError(400, 'description too long (max 2000)');
    out.description = d;
  }
  if (!partial || b.image_url !== undefined) {
    const u = String(b.image_url ?? '').trim();
    if (u && !/^https?:\/\//i.test(u)) throw new HttpError(400, 'image_url must start with http(s)://');
    out.image_url = u;
  }
  return out;
}

const ITEM_SQL = `
  SELECT i.id, i.name, i.description, i.image_url,
         COALESCE(ROUND(AVG(r.rating), 2), 0) AS avg_rating,
         COUNT(r.id) AS review_count
  FROM items i LEFT JOIN reviews r ON r.item_id = i.id`;
const getItem = (env, id) => env.DB.prepare(`${ITEM_SQL} WHERE i.id = ? GROUP BY i.id`).bind(id).first();
const now = () => Math.floor(Date.now() / 1000);

// Anonymous, salted hash of the caller's IP — used only to rate-limit guest reviews.
async function ipHash(req, env) {
  const ip = req.headers.get('cf-connecting-ip') || 'unknown';
  return b64u(await crypto.subtle.digest('SHA-256', enc.encode(ip + env.JWT_SECRET))).slice(0, 22);
}

// ---------- routes ----------
async function handle(req, env) {
  const url = new URL(req.url);
  const path = url.pathname.replace(/\/+$/, '') || '/';
  const method = req.method;
  let m;

  if (method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });

  if (path === '/' && method === 'GET') return json({ app: 'rating-worker', ok: true });

  // Browser-based admin panel (the page is static; every action needs the admin token)
  if (path === '/panel' && method === 'GET')
    return new Response(PANEL_HTML, {
      headers: {
        'content-type': 'text/html; charset=utf-8',
        'x-frame-options': 'DENY',
        'referrer-policy': 'no-referrer',
        'content-security-policy':
          "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src https: data:; connect-src 'self'",
      },
    });

  // ----- public: auth -----
  if (path === '/api/signup' && method === 'POST') {
    const { username = '', password = '' } = await readBody(req);
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) throw new HttpError(400, 'Username: 3-20 letters, numbers or _');
    if (['guest', 'anonymous', 'admin'].includes(username.toLowerCase())) throw new HttpError(400, 'That username is reserved');
    if (password.length < 6 || password.length > 200) throw new HttpError(400, 'Password must be at least 6 characters');
    try {
      const r = await env.DB.prepare('INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?)')
        .bind(username, await hashPassword(password), now()).run();
      return authResponse(env, r.meta.last_row_id, username);
    } catch (e) {
      if (String(e).includes('UNIQUE')) throw new HttpError(409, 'Username already taken');
      throw e;
    }
  }
  if (path === '/api/login' && method === 'POST') {
    const { username = '', password = '' } = await readBody(req);
    const u = await env.DB.prepare('SELECT id, username, password_hash FROM users WHERE username = ?').bind(username).first();
    if (!u || !(await checkPassword(password, u.password_hash))) throw new HttpError(401, 'Wrong username or password');
    return authResponse(env, u.id, u.username);
  }

  // ----- public: items & reviews -----
  if (path === '/api/items' && method === 'GET') {
    const { results } = await env.DB.prepare(`${ITEM_SQL} GROUP BY i.id ORDER BY i.id DESC`).all();
    return json({ items: results });
  }
  if ((m = path.match(/^\/api\/items\/(\d+)$/)) && method === 'GET') {
    const user = await getUser(req, env);
    const item = await getItem(env, +m[1]);
    if (!item) throw new HttpError(404, 'Item not found');
    const { results } = await env.DB.prepare(
      'SELECT id, author, rating, text, created_at FROM reviews WHERE item_id = ? ORDER BY created_at DESC, id DESC LIMIT 200'
    ).bind(+m[1]).all();
    const my_review = user
      ? await env.DB.prepare('SELECT id, rating, text FROM reviews WHERE item_id = ? AND user_id = ?').bind(+m[1], user.id).first()
      : null;
    return json({ item, reviews: results, my_review });
  }
  if ((m = path.match(/^\/api\/items\/(\d+)\/reviews$/)) && method === 'POST') {
    const user = await getUser(req, env); // null => guest
    const { rating, text = '' } = await readBody(req);
    if (!Number.isInteger(rating) || rating < 1 || rating > 10) throw new HttpError(400, 'rating must be an integer 1-10');
    if (String(text).length > 2000) throw new HttpError(400, 'Review too long (max 2000)');
    if (!(await getItem(env, +m[1]))) throw new HttpError(404, 'Item not found');
    if (user) {
      await env.DB.prepare(
        `INSERT INTO reviews (item_id, user_id, author, rating, text, created_at) VALUES (?, ?, ?, ?, ?, ?)
         ON CONFLICT(item_id, user_id) WHERE user_id IS NOT NULL
         DO UPDATE SET rating = excluded.rating, text = excluded.text, created_at = excluded.created_at`
      ).bind(+m[1], user.id, user.username, rating, String(text).trim(), now()).run();
    } else {
      // Guests: 1 review per item per day, and 30 per day overall, per (hashed) IP
      const h = await ipHash(req, env);
      const recent = await env.DB.prepare(
        'SELECT SUM(item_id = ?) AS same_item, COUNT(*) AS total FROM reviews WHERE user_id IS NULL AND ip_hash = ? AND created_at > ?'
      ).bind(+m[1], h, now() - 86400).first();
      if ((recent?.same_item ?? 0) > 0) throw new HttpError(429, 'You already reviewed this as a guest today. Log in to edit your review.');
      if ((recent?.total ?? 0) >= 30) throw new HttpError(429, 'Too many guest reviews today. Please log in.');
      await env.DB.prepare('INSERT INTO reviews (item_id, user_id, author, rating, text, created_at, ip_hash) VALUES (?, NULL, ?, ?, ?, ?, ?)')
        .bind(+m[1], 'Guest', rating, String(text).trim(), now(), h).run();
    }
    return json({ ok: true }, 201);
  }
  if ((m = path.match(/^\/api\/items\/(\d+)\/reviews\/mine$/)) && method === 'DELETE') {
    const user = await getUser(req, env);
    if (!user) throw new HttpError(401, 'Log in first');
    await env.DB.prepare('DELETE FROM reviews WHERE item_id = ? AND user_id = ?').bind(+m[1], user.id).run();
    return json({ ok: true });
  }

  // ----- admin -----
  if (path.startsWith('/admin')) {
    requireAdmin(req, env);
    if (path === '/admin/ping' && method === 'GET') return json({ ok: true });

    if (path === '/admin/items' && method === 'POST') {
      const it = cleanItem(await readBody(req), false);
      const r = await env.DB.prepare('INSERT INTO items (name, description, image_url, created_at) VALUES (?, ?, ?, ?)')
        .bind(it.name, it.description, it.image_url, now()).run();
      return json(await getItem(env, r.meta.last_row_id), 201);
    }
    if ((m = path.match(/^\/admin\/items\/(\d+)$/))) {
      const id = +m[1];
      if (!(await getItem(env, id))) throw new HttpError(404, 'Item not found');
      if (method === 'PUT') {
        const it = cleanItem(await readBody(req), true);
        const keys = Object.keys(it);
        if (!keys.length) throw new HttpError(400, 'Nothing to update');
        await env.DB.prepare(`UPDATE items SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`)
          .bind(...keys.map((k) => it[k]), id).run();
        return json(await getItem(env, id));
      }
      if (method === 'DELETE') {
        await env.DB.batch([
          env.DB.prepare('DELETE FROM reviews WHERE item_id = ?').bind(id),
          env.DB.prepare('DELETE FROM items WHERE id = ?').bind(id),
        ]);
        return json({ ok: true });
      }
    }
    if ((m = path.match(/^\/admin\/reviews\/(\d+)$/)) && method === 'DELETE') {
      await env.DB.prepare('DELETE FROM reviews WHERE id = ?').bind(+m[1]).run();
      return json({ ok: true });
    }
  }

  throw new HttpError(404, 'Not found');
}

export default {
  async fetch(req, env) {
    try { return await handle(req, env); }
    catch (e) {
      if (e instanceof HttpError) return json({ error: e.message }, e.status);
      console.error(e);
      return json({ error: 'Server error' }, 500);
    }
  },
};

// ---------- admin panel page (served at /panel) ----------
const PANEL_HTML = String.raw`<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Rating admin</title>
<style>
:root{color-scheme:light dark;font-family:system-ui,sans-serif}
body{max-width:760px;margin:0 auto;padding:16px}
input,textarea,button{font:inherit;padding:8px 10px;border-radius:8px;border:1px solid #8884;margin:4px 0}
input,textarea{width:100%;box-sizing:border-box;background:transparent;color:inherit}
button{cursor:pointer;background:#6d4aff;color:#fff;border:0;margin-right:6px}
button.danger{background:#d33}button.ghost{background:#8883;color:inherit}
.card{border:1px solid #8884;border-radius:12px;padding:12px;margin:12px 0}
.card img{width:100%;max-height:200px;object-fit:cover;border-radius:8px}
.muted{opacity:.7;font-size:.9em}.rev{border-top:1px solid #8883;padding:6px 0}
#err{color:#d33}
</style></head><body>
<h1>Rating admin</h1>
<section id="login">
  <input id="token" type="password" placeholder="Admin token" autocomplete="off">
  <button id="go">Unlock</button><p id="err"></p>
</section>
<main id="app" hidden>
  <h2 id="formTitle">Add item</h2>
  <form id="form">
    <input id="name" placeholder="Name" required maxlength="100">
    <input id="image" placeholder="Image URL (https://...)">
    <textarea id="desc" placeholder="Description" rows="3" maxlength="2000"></textarea>
    <button>Save</button><button type="button" id="cancel" class="ghost" hidden>Cancel edit</button>
  </form>
  <div id="list"></div>
</main>
<script>
var token = sessionStorage.getItem('t') || '', editId = null;
function $(id){return document.getElementById(id)}
function el(tag, props, kids){var e=document.createElement(tag);Object.assign(e,props||{});(kids||[]).forEach(function(k){e.append(k)});return e}
function btn(label, fn, cls){return el('button',{textContent:label,className:cls||'',onclick:fn,type:'button'})}
async function api(method, path, body){
  var r = await fetch(path,{method:method,headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});
  var j = await r.json().catch(function(){return {}});
  if(!r.ok) throw new Error(j.error || ('HTTP '+r.status));
  return j;
}
async function unlock(){
  token = $('token').value || token;
  try{ await api('GET','/admin/ping'); sessionStorage.setItem('t',token); $('login').hidden=true; $('app').hidden=false; await load(); }
  catch(e){ $('err').textContent = e.message; }
}
async function load(){
  var data = await (await fetch('/api/items')).json();
  var box = $('list'); box.textContent = '';
  data.items.forEach(function(it){
    var c = el('div',{className:'card'});
    if(it.image_url) c.append(el('img',{src:it.image_url,alt:''}));
    var rv = el('div');
    c.append(el('b',{textContent:it.name}),
      el('div',{className:'muted',textContent:it.review_count ? ('\u2605 '+it.avg_rating+' / 10 \u00b7 '+it.review_count+' reviews') : 'No ratings yet'}),
      el('p',{textContent:it.description}),
      btn('Edit',function(){startEdit(it)}),
      btn('Reviews',function(){toggleReviews(it,rv)},'ghost'),
      btn('Delete',function(){del(it)},'danger'), rv);
    box.append(c);
  });
}
function startEdit(it){editId=it.id;$('name').value=it.name;$('image').value=it.image_url;$('desc').value=it.description;$('formTitle').textContent='Edit item #'+it.id;$('cancel').hidden=false;window.scrollTo(0,0)}
function resetForm(){editId=null;$('form').reset();$('formTitle').textContent='Add item';$('cancel').hidden=true}
async function del(it){ if(!confirm('Delete "'+it.name+'" and all its reviews?')) return; try{await api('DELETE','/admin/items/'+it.id);await load()}catch(e){alert(e.message)} }
async function toggleReviews(it, box){
  if(box.childNodes.length){box.textContent='';return}
  var d = await (await fetch('/api/items/'+it.id)).json();
  if(!d.reviews.length) box.append(el('p',{className:'muted',textContent:'No reviews'}));
  d.reviews.forEach(function(r){
    box.append(el('div',{className:'rev'},[
      el('b',{textContent:r.author+'  \u2605 '+r.rating+'/10  '}), el('span',{textContent:r.text}),
      btn('Remove',async function(){ try{await api('DELETE','/admin/reviews/'+r.id);await load()}catch(e){alert(e.message)} },'danger')]));
  });
}
$('go').onclick = unlock;
$('cancel').onclick = resetForm;
$('form').onsubmit = async function(e){
  e.preventDefault();
  var b = {name:$('name').value,image_url:$('image').value,description:$('desc').value};
  try{ if(editId) await api('PUT','/admin/items/'+editId,b); else await api('POST','/admin/items',b); resetForm(); await load(); }
  catch(x){ alert(x.message) }
};
if(token){ $('token').value = token; unlock(); }
</script></body></html>`;
