package com.example.ratingapp

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class ApiException(message: String, val code: Int = 0) : Exception(message)

/** "my-worker.me.workers.dev/" -> "https://my-worker.me.workers.dev" (null if invalid) */
fun normalizeUrl(raw: String): String? {
    var s = raw.trim()
    if (s.isEmpty()) return null
    if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "https://$s"
    return s.toHttpUrlOrNull()?.toString()?.trimEnd('/')
}

class Api(private val baseUrl: String, private val token: () -> String?) {
    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }

    private suspend fun call(verb: String, path: String, body: JsonObject? = null): String =
        withContext(Dispatchers.IO) {
            val req = Request.Builder().url(baseUrl + path).apply {
                token()?.let { header("Authorization", "Bearer $it") }
                if (verb == "GET") get()
                else method(verb, (body?.toString() ?: "{}").toRequestBody("application/json".toMediaType()))
            }.build()
            try {
                client.newCall(req).execute().use { r ->
                    val text = r.body?.string().orEmpty()
                    if (!r.isSuccessful) {
                        val msg = runCatching {
                            json.parseToJsonElement(text).jsonObject["error"]?.jsonPrimitive?.content
                        }.getOrNull()
                        throw ApiException(msg ?: "Server error (${r.code})", r.code)
                    }
                    text
                }
            } catch (e: IOException) {
                throw ApiException("Can't reach server: ${e.message}")
            }
        }

    suspend fun ping() {
        val t = try { call("GET", "/") } catch (e: ApiException) { throw ApiException("That doesn't look like the rating server") }
        if (!t.contains("rating-worker")) throw ApiException("That doesn't look like the rating server")
    }

    private fun creds(u: String, p: String) = buildJsonObject { put("username", u); put("password", p) }
    suspend fun login(u: String, p: String) =
        json.decodeFromString<AuthResponse>(call("POST", "/api/login", creds(u, p)))
    suspend fun signup(u: String, p: String) =
        json.decodeFromString<AuthResponse>(call("POST", "/api/signup", creds(u, p)))

    suspend fun items() = json.decodeFromString<ItemsResponse>(call("GET", "/api/items")).items
    suspend fun detail(id: Int) = json.decodeFromString<ItemDetail>(call("GET", "/api/items/$id"))
    suspend fun deleteMyReview(id: Int) { call("DELETE", "/api/items/$id/reviews/mine") }
    suspend fun postReview(id: Int, rating: Int, text: String) {
        call("POST", "/api/items/$id/reviews", buildJsonObject { put("rating", rating); put("text", text) })
    }
}
