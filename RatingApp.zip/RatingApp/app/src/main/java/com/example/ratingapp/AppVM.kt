package com.example.ratingapp

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class AppVM(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var baseUrl by mutableStateOf(store.baseUrl)
    var token by mutableStateOf(store.token)
    var username by mutableStateOf(store.username)
    var items by mutableStateOf<List<Item>>(emptyList())
    var detail by mutableStateOf<ItemDetail?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var notice by mutableStateOf<String?>(null)
    var query by mutableStateOf("")
    var sort by mutableStateOf(Sort.Newest)
    var screen by mutableStateOf<Screen>(if (store.baseUrl == null) Screen.Setup else Screen.Home)

    private var api: Api? = store.baseUrl?.let { Api(it) { token } }

    val canGoBack get() = screen !is Screen.Home && !(screen is Screen.Setup && baseUrl == null)

    val visibleItems: List<Item>
        get() {
            val q = query.trim()
            val filtered = if (q.isEmpty()) items
            else items.filter { it.name.contains(q, true) || it.description.contains(q, true) }
            return when (sort) {
                Sort.Newest -> filtered.sortedByDescending { it.id }
                Sort.Top -> filtered.sortedWith(compareByDescending<Item> { it.avgRating }.thenByDescending { it.reviewCount })
                Sort.Popular -> filtered.sortedByDescending { it.reviewCount }
            }
        }

    init { if (api != null) refresh() }

    private fun launch(block: suspend () -> Unit) = viewModelScope.launch {
        loading = true
        error = null
        notice = null
        try {
            block()
        } catch (e: ApiException) {
            if (e.code == 401 && token != null) { logout(); error = e.message } else error = e.message
        } catch (e: Exception) {
            error = e.message ?: "Something went wrong"
        } finally {
            loading = false
        }
    }

    private fun requireApi() = api ?: throw ApiException("Not connected to a server")

    fun go(s: Screen) { error = null; notice = null; screen = s }
    fun back() { go(Screen.Home) }

    fun connect(raw: String) = launch {
        val url = normalizeUrl(raw) ?: throw ApiException("Please enter a valid URL")
        val a = Api(url) { token }
        a.ping()
        if (url != baseUrl) { // different server => old session is meaningless
            store.token = null; store.username = null; token = null; username = null
            items = emptyList()
        }
        store.baseUrl = url; baseUrl = url; api = a
        screen = Screen.Home
        items = a.items()
    }

    fun refresh() { launch { items = requireApi().items() } }

    fun openItem(id: Int) {
        detail = null
        go(Screen.Detail(id))
        launch { detail = requireApi().detail(id) }
    }

    fun submitReview(id: Int, rating: Int, text: String, onDone: () -> Unit) = launch {
        if (rating == 0) throw ApiException("Pick a rating from 1 to 10 first")
        val a = requireApi()
        a.postReview(id, rating, text)
        detail = a.detail(id)
        items = a.items()
        notice = if (token != null) "Review saved" else "Thanks for your review!"
        onDone()
    }

    fun deleteMyReview(id: Int) = launch {
        val a = requireApi()
        a.deleteMyReview(id)
        detail = a.detail(id)
        items = a.items()
        notice = "Review deleted"
    }

    fun auth(login: Boolean, user: String, pass: String) = launch {
        val a = requireApi()
        val r = if (login) a.login(user.trim(), pass) else a.signup(user.trim(), pass)
        store.token = r.token; store.username = r.username
        token = r.token; username = r.username
        screen = Screen.Home
        items = a.items()
    }

    fun logout() {
        store.token = null; store.username = null
        token = null; username = null
    }
}
