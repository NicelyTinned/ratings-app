package com.example.ratingapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

private val LightRatings = lightColorScheme(
    primary = Color(0xFF5D5AE8), onPrimary = Color.White,
    primaryContainer = Color(0xFFE5E3FF), onPrimaryContainer = Color(0xFF211E67),
    secondary = Color(0xFF5377A8), onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0EAFF), onSecondaryContainer = Color(0xFF152D50),
    tertiary = Color(0xFF98601C), onTertiary = Color.White,
    background = Color(0xFFF6F6FC), onBackground = Color(0xFF1B1B2A),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF1B1B2A),
    surfaceVariant = Color(0xFFEBEAF5), onSurfaceVariant = Color(0xFF62627A),
    outline = Color(0xFF87869E), outlineVariant = Color(0xFFD7D6E5),
)
private val DarkRatings = darkColorScheme(
    primary = Color(0xFFB9B5FF), onPrimary = Color(0xFF29236B),
    primaryContainer = Color(0xFF39358B), onPrimaryContainer = Color(0xFFE3E0FF),
    secondary = Color(0xFFAFC9F5), onSecondary = Color(0xFF1C3455),
    secondaryContainer = Color(0xFF354D70), onSecondaryContainer = Color(0xFFD9E6FF),
    tertiary = Color(0xFFFFC27C), onTertiary = Color(0xFF472900),
    background = Color(0xFF10111D), onBackground = Color(0xFFECEBFA),
    surface = Color(0xFF191A2A), onSurface = Color(0xFFECEBFA),
    surfaceVariant = Color(0xFF292A40), onSurfaceVariant = Color(0xFFB8B7D0),
    outline = Color(0xFF77768F), outlineVariant = Color(0xFF44445B),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = androidx.compose.foundation.isSystemInDarkTheme()
            MaterialTheme(
                colorScheme = if (dark) DarkRatings else LightRatings,
                shapes = Shapes(
                    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                    small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                    medium = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                    large = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
                ),
            ) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val vm: AppVM = viewModel()
                    BackHandler(enabled = vm.canGoBack) { vm.back() }
                    when (val s = vm.screen) {
                        Screen.Setup -> SetupScreen(vm)
                        Screen.Home -> HomeScreen(vm)
                        Screen.Auth -> AuthScreen(vm)
                        Screen.AddItem -> AddItemScreen(vm)
                        is Screen.Detail -> DetailScreen(vm, s.id)
                    }
                }
            }
        }
    }
}
