@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.ratingapp

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private val Gold = Color(0xFFFFB400)

private fun fmt(d: Double) = String.format(Locale.US, "%.1f", d)

@Composable
private fun ErrorText(msg: String?) {
    if (msg != null) Text(msg, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 4.dp))
}

@Composable
private fun RatingBadge(item: Item) {
    if (item.reviewCount == 0) {
        Text("No ratings yet", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    } else {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Gold, shape = RoundedCornerShape(8.dp)) {
                Text(
                    "★ ${fmt(item.avgRating)}", Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    color = Color.Black, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge,
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                "/ 10 · ${item.reviewCount} review${if (item.reviewCount == 1) "" else "s"}",
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ItemImage(url: String, modifier: Modifier = Modifier) {
    val m = modifier.aspectRatio(16 / 9f).clip(RoundedCornerShape(12.dp)).background(Color.Gray.copy(alpha = 0.25f))
    if (url.isBlank()) Box(m)
    else AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = m)
}

// ---------------- Setup ----------------
@Composable
fun SetupScreen(vm: AppVM) {
    var url by remember { mutableStateOf(vm.baseUrl ?: "") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Connect to a server", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("Enter the URL of your Cloudflare Worker.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = url, onValueChange = { url = it },
            label = { Text("Server URL") },
            placeholder = { Text("rating-app.you.workers.dev") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { vm.connect(url) }),
            modifier = Modifier.fillMaxWidth(),
        )
        ErrorText(vm.error)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { vm.connect(url) }, enabled = !vm.loading && url.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            if (vm.loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("Connect")
        }
    }
}

// ---------------- Home ----------------
@Composable
fun HomeScreen(vm: AppVM) {
    var menu by remember { mutableStateOf(false) }
    Scaffold(topBar = {
        TopAppBar(
            title = {
                Column {
                    Text("Ratings")
                    Text(vm.username ?: "Guest", style = MaterialTheme.typography.labelSmall)
                }
            },
            actions = {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (vm.token == null)
                        DropdownMenuItem(text = { Text("Log in / Sign up") }, onClick = { menu = false; vm.go(Screen.Auth) })
                    else
                        DropdownMenuItem(text = { Text("Log out") }, onClick = { menu = false; vm.logout() })
                    DropdownMenuItem(text = { Text("Change server") }, onClick = { menu = false; vm.go(Screen.Setup) })
                }
            },
        )
    }) { pad ->
        when {
            vm.items.isEmpty() && vm.loading ->
                Box(Modifier.padding(pad).fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            vm.items.isEmpty() ->
                Column(Modifier.padding(pad).fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                    ErrorText(vm.error)
                    if (vm.error == null) Text("No items yet. The admin can add some.")
                    TextButton(onClick = { vm.refresh() }) { Text("Retry") }
                }
            else -> PullToRefreshBox(
                isRefreshing = vm.loading, onRefresh = { vm.refresh() },
                modifier = Modifier.padding(pad).fillMaxSize(),
            ) {
                val shown = vm.visibleItems
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = vm.query, onValueChange = { vm.query = it },
                                placeholder = { Text("Search") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                                trailingIcon = { if (vm.query.isNotEmpty()) TextButton(onClick = { vm.query = "" }) { Text("Clear") } },
                            )
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Sort.entries.forEach { s ->
                                    FilterChip(selected = vm.sort == s, onClick = { vm.sort = s }, label = { Text(s.label) })
                                }
                            }
                            ErrorText(vm.error)
                        }
                    }
                    if (shown.isEmpty()) item { Text("No matches for \"${vm.query}\"", Modifier.padding(16.dp)) }
                    items(shown, key = { it.id }) { item ->
                        Card(Modifier.fillMaxWidth().clickable { vm.openItem(item.id) }) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                ItemImage(item.imageUrl, Modifier.fillMaxWidth())
                                Text(item.name, style = MaterialTheme.typography.titleMedium)
                                RatingBadge(item)
                                if (item.description.isNotBlank())
                                    Text(item.description, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- Auth ----------------
@Composable
fun AuthScreen(vm: AppVM) {
    var login by remember { mutableStateOf(true) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (login) "Log in" else "Sign up") },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
        )
    }) { pad ->
        Column(Modifier.padding(pad).padding(24.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(user, { user = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                pass, { pass = it }, label = { Text("Password") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { vm.auth(login, user, pass) }),
                modifier = Modifier.fillMaxWidth(),
            )
            ErrorText(vm.error)
            Button(onClick = { vm.auth(login, user, pass) }, enabled = !vm.loading && user.isNotBlank() && pass.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                if (vm.loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text(if (login) "Log in" else "Create account")
            }
            TextButton(onClick = { login = !login; vm.error = null }) {
                Text(if (login) "No account? Sign up" else "Have an account? Log in")
            }
            TextButton(onClick = { vm.back() }) { Text("Continue as guest") }
        }
    }
}

// ---------------- Detail ----------------
@Composable
private fun StarPicker(value: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth()) {
        for (i in 1..10) {
            Icon(
                Icons.Filled.Star, contentDescription = "$i stars",
                tint = if (i <= value) Gold else Color.Gray.copy(alpha = 0.35f),
                modifier = Modifier.weight(1f).height(32.dp).clickable { onChange(i) },
            )
        }
    }
}

@Composable
private fun Histogram(reviews: List<Review>) {
    val counts = IntArray(11)
    reviews.forEach { counts[it.rating.coerceIn(1, 10)]++ }
    val max = counts.max().coerceAtLeast(1)
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        for (s in 10 downTo 1) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$s", Modifier.width(22.dp), style = MaterialTheme.typography.labelSmall)
                Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color.Gray.copy(alpha = 0.2f))) {
                    Box(Modifier.fillMaxWidth(counts[s] / max.toFloat()).fillMaxHeight().background(Gold))
                }
                Text("${counts[s]}", Modifier.width(32.dp).padding(start = 6.dp), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun DetailScreen(vm: AppVM, id: Int) {
    val d = vm.detail
    var rating by remember { mutableIntStateOf(0) }
    var text by remember { mutableStateOf("") }
    // Pre-fill the form with the logged-in user's existing review
    LaunchedEffect(d?.myReview) {
        rating = d?.myReview?.rating ?: 0
        text = d?.myReview?.text ?: ""
    }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(d?.item?.name ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
        )
    }) { pad ->
        if (d == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                if (vm.error != null) ErrorText(vm.error) else CircularProgressIndicator()
            }
        } else {
            val signedIn = vm.token != null
            val mine = d.myReview
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    ItemImage(d.item.imageUrl, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Text(d.item.name, style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(4.dp))
                    RatingBadge(d.item)
                    if (d.item.description.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(d.item.description)
                    }
                }
                if (d.reviews.isNotEmpty()) item { Histogram(d.reviews) }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(if (mine != null) "Your review" else "Leave a review", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (signedIn) "Posting as ${vm.username}" else "Posting as Guest · log in to edit reviews later",
                                style = MaterialTheme.typography.labelMedium,
                            )
                            StarPicker(rating) { rating = it }
                            Text(if (rating == 0) "Tap a star" else "$rating / 10", style = MaterialTheme.typography.labelLarge)
                            OutlinedTextField(text, { text = it }, label = { Text("Your review (optional)") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                            ErrorText(vm.error)
                            vm.notice?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                            Button(
                                onClick = { vm.submitReview(id, rating, text) { if (!signedIn) { rating = 0; text = "" } } },
                                enabled = !vm.loading, modifier = Modifier.fillMaxWidth(),
                            ) { Text(if (mine != null) "Update review" else "Submit") }
                            if (mine != null) TextButton(onClick = { vm.deleteMyReview(id) }, enabled = !vm.loading) { Text("Delete my review") }
                        }
                    }
                }
                item { Text("Reviews (${d.reviews.size})", style = MaterialTheme.typography.titleMedium) }
                items(d.reviews, key = { it.id }) { r ->
                    Column(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(r.author, style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.width(8.dp))
                            Text("★ ${r.rating}/10", color = Gold, style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.weight(1f))
                            Text(DateFormat.getDateInstance().format(Date(r.createdAt * 1000)), style = MaterialTheme.typography.labelSmall)
                        }
                        if (r.text.isNotBlank()) Text(r.text)
                        HorizontalDivider(Modifier.padding(top = 8.dp))
                    }
                }
            }
        }
    }
}
