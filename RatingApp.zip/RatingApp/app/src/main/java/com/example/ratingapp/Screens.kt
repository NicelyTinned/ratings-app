@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.ratingapp

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private val Gold = Color(0xFFFFB95C)
private val SoftBorder = Color(0xFF8A8EB8).copy(alpha = 0.22f)

private fun fmt(d: Double) = String.format(Locale.US, "%.1f", d)

@Composable
private fun ErrorText(msg: String?) {
    if (msg != null) Text(msg, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 4.dp))
}

@Composable
private fun RatingBadge(item: Item) {
    if (item.reviewCount == 0) {
        Text("No ratings yet", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    } else {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Gold, shape = RoundedCornerShape(9.dp)) {
                Text(
                    "★ ${fmt(item.avgRating)}", Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                    color = Color(0xFF241A11), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge,
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                "/ 10 · ${item.reviewCount} review${if (item.reviewCount == 1) "" else "s"}",
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ItemImage(url: String, modifier: Modifier = Modifier) {
    val m = modifier.aspectRatio(16 / 9f).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
    if (url.isBlank()) {
        Box(m, contentAlignment = Alignment.Center) {
            Text("NO IMAGE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = m)
    }
}

@Composable
private fun TagsRow(tags: List<String>, compact: Boolean = false) {
    if (tags.isNotEmpty()) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            tags.forEach { tag ->
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(999.dp),
                ) {
                    Text(
                        "#${tag}",
                        modifier = Modifier.padding(horizontal = if (compact) 8.dp else 10.dp, vertical = if (compact) 3.dp else 5.dp),
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        style = if (compact) MaterialTheme.typography.labelSmall else MaterialTheme.typography.labelMedium,
                    )
                }
            }
        }
    }
}

// ---------------- Server setup ----------------
@Composable
fun SetupScreen(vm: AppVM) {
    var url by remember { mutableStateOf(vm.baseUrl?.takeUnless { normalizeUrl(it) == normalizeUrl(AppVM.PUBLIC_SERVER_URL) } ?: "") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(18.dp)) {
            Text("RATINGS NETWORK", Modifier.padding(horizontal = 14.dp, vertical = 8.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Spacer(Modifier.height(18.dp))
        Text("Find your\nratings space.", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text("Join the community catalogue or connect to a private server with its own admin and approval queue.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Community server", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("A shared catalogue. Sign in to publish new items, with your username shown as the contributor.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { vm.connect(AppVM.PUBLIC_SERVER_URL) }, enabled = !vm.loading, modifier = Modifier.fillMaxWidth()) {
                    if (vm.loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Join community")
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Private server", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Connect using the server URL shared by its owner. Your additions go to the admin for approval.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(
                    value = url, onValueChange = { url = it },
                    label = { Text("Private server URL") },
                    placeholder = { Text("your-server.workers.dev") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { vm.connect(url) }),
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(onClick = { vm.connect(url) }, enabled = !vm.loading && url.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                    Text("Connect to private server")
                }
            }
        }
        ErrorText(vm.error)
        Spacer(Modifier.height(8.dp))
        Text("Server URLs are supplied by their owners. Your account is separate on each server.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------------- Catalogue ----------------
@Composable
fun HomeScreen(vm: AppVM) {
    var menu by remember { mutableStateOf(false) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(vm.serverConfig?.name ?: "Ratings", fontWeight = FontWeight.Bold)
                        Text(
                            "${vm.username ?: "Browsing as guest"} · ${vm.serverConfig?.mode?.uppercase() ?: "SERVER"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                actions = {
                    if (vm.token != null) {
                        IconButton(onClick = { vm.go(Screen.AddItem) }) { Icon(Icons.Default.Add, "Add item") }
                    }
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (vm.token == null) {
                            DropdownMenuItem(text = { Text("Log in / Sign up") }, onClick = { menu = false; vm.go(Screen.Auth) })
                        } else {
                            DropdownMenuItem(text = { Text("Log out") }, onClick = { menu = false; vm.logout() })
                        }
                        DropdownMenuItem(text = { Text("Change server") }, onClick = { menu = false; vm.go(Screen.Setup) })
                    }
                },
            )
        },
    ) { pad ->
        PullToRefreshBox(
            isRefreshing = vm.loading,
            onRefresh = { vm.refresh() },
            modifier = Modifier.padding(pad).fillMaxSize(),
        ) {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = vm.query, onValueChange = { vm.query = it },
                            placeholder = { Text("Search items, tags, descriptions...") },
                            singleLine = true, modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            trailingIcon = { if (vm.query.isNotEmpty()) TextButton(onClick = { vm.query = "" }) { Text("Clear") } },
                        )
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Sort.entries.forEach { s ->
                                FilterChip(selected = vm.sort == s, onClick = { vm.sort = s }, label = { Text(s.label) })
                            }
                        }
                        if (vm.availableTags.isNotEmpty()) {
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = vm.selectedTag == null, onClick = { vm.selectedTag = null }, label = { Text("All tags") })
                                vm.availableTags.forEach { tag ->
                                    FilterChip(selected = vm.selectedTag == tag, onClick = { vm.selectedTag = if (vm.selectedTag == tag) null else tag }, label = { Text("#$tag") })
                                }
                            }
                        }
                        vm.notice?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium) }
                        ErrorText(vm.error)
                        if (vm.token != null) {
                            FilledTonalButton(onClick = { vm.go(Screen.AddItem) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Add, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (vm.serverConfig?.mode == "public") "Add to community catalogue" else "Suggest an item")
                            }
                        } else {
                            TextButton(onClick = { vm.go(Screen.Auth) }) { Text("Log in to add or suggest an item") }
                        }
                    }
                }
                val shown = vm.visibleItems
                when {
                    vm.items.isEmpty() && vm.loading -> item {
                        Box(Modifier.fillMaxWidth().padding(vertical = 50.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    }
                    shown.isEmpty() -> item {
                        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(if (vm.items.isEmpty()) "A fresh start." else "No matches found.", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text(if (vm.items.isEmpty()) "The catalogue is waiting for its first additions." else "Try a different search or remove the tag filter.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (vm.items.isEmpty() && vm.token != null) Button(onClick = { vm.go(Screen.AddItem) }) { Text(if (vm.serverConfig?.mode == "public") "Add the first item" else "Suggest the first item") }
                                TextButton(onClick = { vm.refresh() }) { Text("Refresh") }
                            }
                        }
                    }
                    else -> items(shown, key = { it.id }) { item ->
                        Card(
                            Modifier.fillMaxWidth().clickable { vm.openItem(item.id) },
                            shape = RoundedCornerShape(22.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SoftBorder),
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                ItemImage(item.imageUrl, Modifier.fillMaxWidth())
                                Text(item.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                RatingBadge(item)
                                if (item.description.isNotBlank()) Text(item.description, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                                TagsRow(item.tags, compact = true)
                                Text("Added by ${item.addedBy}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- Add / suggest item ----------------
@Composable
fun AddItemScreen(vm: AppVM) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var image by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }
    val isPublic = vm.serverConfig?.mode == "public"
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (isPublic) "Add to catalogue" else "Suggest an item") },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Card(shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (isPublic) "Publish a community entry" else "Send an idea to the admin", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        if (isPublic) "Your item appears in the catalogue right away. Your username will be shown as its contributor."
                        else "Your suggestion enters the moderation queue. The admin can approve or reject it, and your username stays attached if it is approved.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text("Submitting as ${vm.username ?: "Guest"}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
            }
            OutlinedTextField(name, { name = it }, label = { Text("Item name") }, singleLine = true, supportingText = { Text("Up to 100 characters") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(description, { description = it }, label = { Text("Description") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(image, { image = it }, label = { Text("Image URL (optional)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(tags, { tags = it }, label = { Text("Tags") }, placeholder = { Text("e.g. books, cozy, sci-fi") }, supportingText = { Text("Separate with commas. Up to 8 tags, 24 characters each.") }, modifier = Modifier.fillMaxWidth())
            ErrorText(vm.error)
            Button(
                onClick = { vm.addItem(name, description, image, tags) },
                enabled = !vm.loading && name.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (vm.loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                else Text(if (isPublic) "Publish item" else "Send suggestion")
            }
            TextButton(onClick = { vm.back() }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Cancel") }
        }
    }
}

// ---------------- Authentication ----------------
@Composable
fun AuthScreen(vm: AppVM) {
    var login by remember { mutableStateOf(true) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (login) "Welcome back" else "Create account") },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
        )
    }) { pad ->
        Column(Modifier.padding(pad).padding(24.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(if (login) "Log in to your server" else "Join this server", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Accounts are separate for each server. New passwords must be at least 8 characters.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(user, { user = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                pass, { pass = it }, label = { Text("Password") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { vm.auth(login, user, pass) }),
                modifier = Modifier.fillMaxWidth(),
            )
            ErrorText(vm.error)
            Button(onClick = { vm.auth(login, user, pass) }, enabled = !vm.loading && user.isNotBlank() && pass.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                if (vm.loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text(if (login) "Log in" else "Create account")
            }
            TextButton(onClick = { login = !login; vm.clearError() }) {
                Text(if (login) "New here? Create an account" else "Already have an account? Log in")
            }
            TextButton(onClick = { vm.back() }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Continue as guest") }
        }
    }
}

// ---------------- Item detail / reviews / reports ----------------
@Composable
private fun StarPicker(value: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth()) {
        for (i in 1..10) {
            Icon(
                Icons.Filled.Star, contentDescription = "$i rating",
                tint = if (i <= value) Gold else MaterialTheme.colorScheme.outlineVariant,
                modifier = Modifier.weight(1f).height(32.dp).clickable { onChange(i) },
            )
        }
    }
}

@Composable
private fun Histogram(reviews: List<Review>) {
    val counts = IntArray(11)
    reviews.forEach { counts[it.rating.coerceIn(1, 10)]++ }
    val max = counts.max().coerceAtLeast(1)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (score in 10 downTo 1) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$score", Modifier.width(22.dp), style = MaterialTheme.typography.labelSmall)
                Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                    Box(Modifier.fillMaxWidth(counts[score] / max.toFloat()).fillMaxHeight().background(Gold))
                }
                Text("${counts[score]}", Modifier.width(32.dp).padding(start = 6.dp), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun DetailScreen(vm: AppVM, id: Int) {
    val d = vm.detail
    var rating by remember { mutableIntStateOf(0) }
    var text by remember { mutableStateOf("") }
    var reportType by remember { mutableStateOf<String?>(null) }
    var reportId by remember { mutableIntStateOf(0) }
    var reportReason by remember { mutableStateOf("") }

    LaunchedEffect(d?.myReview) {
        rating = d?.myReview?.rating ?: 0
        text = d?.myReview?.text ?: ""
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(d?.item?.name ?: "Item", maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
        )
    }) { pad ->
        if (d == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                if (vm.error != null) ErrorText(vm.error) else CircularProgressIndicator()
            }
        } else {
            val signedIn = vm.token != null
            val mine = d.myReview
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    ItemImage(d.item.imageUrl, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(14.dp))
                    Text(d.item.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    RatingBadge(d.item)
                    Spacer(Modifier.height(8.dp))
                    Text("Added by ${d.item.addedBy}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    TagsRow(d.item.tags)
                    if (d.item.description.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(d.item.description, style = MaterialTheme.typography.bodyLarge)
                    }
                    if (signedIn) {
                        TextButton(onClick = { reportType = "item"; reportId = id }) { Text("Report this item") }
                    }
                }
                if (d.reviews.isNotEmpty()) item {
                    Card(shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Rating breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Histogram(d.reviews)
                        }
                    }
                }
                item {
                    Card(shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text(if (mine != null) "Your review" else "Leave a review", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                if (signedIn) "Posting as ${vm.username}" else "Posting as Guest · log in to edit reviews later",
                                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            StarPicker(rating) { rating = it }
                            Text(if (rating == 0) "Tap to choose a rating" else "$rating / 10", style = MaterialTheme.typography.labelLarge)
                            OutlinedTextField(text, { text = it }, label = { Text("Your review (optional)") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                            ErrorText(vm.error)
                            vm.notice?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                            Button(onClick = { vm.submitReview(id, rating, text) { if (!signedIn) { rating = 0; text = "" } } }, enabled = !vm.loading, modifier = Modifier.fillMaxWidth()) {
                                Text(if (mine != null) "Update review" else "Submit review")
                            }
                            if (mine != null) TextButton(onClick = { vm.deleteMyReview(id) }, enabled = !vm.loading) { Text("Delete my review") }
                        }
                    }
                }
                item { Text("Community reviews · ${d.reviews.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                items(d.reviews, key = { it.id }) { review ->
                    Card(shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, SoftBorder)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(review.author, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(8.dp))
                                Text("★ ${review.rating}/10", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.labelLarge)
                                Spacer(Modifier.weight(1f))
                                Text(DateFormat.getDateInstance().format(Date(review.createdAt * 1000)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (review.text.isNotBlank()) Text(review.text, Modifier.padding(top = 7.dp), style = MaterialTheme.typography.bodyMedium)
                            if (signedIn) TextButton(onClick = { reportType = "review"; reportId = review.id }) { Text("Report review") }
                        }
                    }
                }
            }
        }
    }

    if (reportType != null) {
        AlertDialog(
            onDismissRequest = { reportType = null; reportReason = "" },
            title = { Text("Report ${if (reportType == "item") "item" else "review"}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tell the server moderators what needs attention.", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(reportReason, { reportReason = it }, label = { Text("Reason") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val type = reportType ?: return@TextButton
                        vm.reportContent(type, reportId, reportReason)
                        reportType = null
                        reportReason = ""
                    },
                    enabled = reportReason.isNotBlank() && !vm.loading,
                ) { Text("Send report") }
            },
            dismissButton = { TextButton(onClick = { reportType = null; reportReason = "" }) { Text("Cancel") } },
        )
    }
}
