package com.example.ratingapp

import android.content.Context

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("rating_app", Context.MODE_PRIVATE)

    var baseUrl: String?
        get() = p.getString("url", null)
        set(v) { p.edit().putString("url", v).apply() }
    var token: String?
        get() = p.getString("token", null)
        set(v) { p.edit().putString("token", v).apply() }
    var username: String?
        get() = p.getString("username", null)
        set(v) { p.edit().putString("username", v).apply() }
}
