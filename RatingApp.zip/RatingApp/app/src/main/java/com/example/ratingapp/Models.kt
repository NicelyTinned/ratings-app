package com.example.ratingapp

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Item(
    val id: Int,
    val name: String,
    val description: String = "",
    @SerialName("image_url") val imageUrl: String = "",
    @SerialName("avg_rating") val avgRating: Double = 0.0,
    @SerialName("review_count") val reviewCount: Int = 0,
)

@Serializable
data class Review(
    val id: Int,
    val author: String,
    val rating: Int,
    val text: String = "",
    @SerialName("created_at") val createdAt: Long = 0,
)

@Serializable data class ItemsResponse(val items: List<Item>)
@Serializable data class MyReview(val id: Int, val rating: Int, val text: String = "")
@Serializable
data class ItemDetail(
    val item: Item,
    val reviews: List<Review>,
    @SerialName("my_review") val myReview: MyReview? = null,
)

enum class Sort(val label: String) { Newest("Newest"), Top("Top rated"), Popular("Most reviewed") }
@Serializable data class AuthResponse(val token: String, val username: String)

sealed interface Screen {
    data object Setup : Screen
    data object Home : Screen
    data object Auth : Screen
    data class Detail(val id: Int) : Screen
}
