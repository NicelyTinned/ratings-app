package com.example.ratingapp

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Item(
    val id: Int,
    val name: String,
    val description: String = "",
    @SerialName("image_url") val imageUrl: String = "",
    @SerialName("avg_rating") val avgRating: Double = 0.0,
    @SerialName("review_count") val reviewCount: Int = 0,
    @SerialName("added_by") val addedBy: String = "Admin",
    val tags: List<String> = emptyList(),
    val status: String = "published",
)

@Serializable
data class Review(
    val id: Int,
    val author: String,
    val rating: Int,
    val text: String = "",
    @SerialName("created_at") val createdAt: Long = 0,
)

@Serializable data class ItemsResponse(val items: List<Item>)
@Serializable data class MyReview(val id: Int, val rating: Int, val text: String = "")
@Serializable
data class ItemDetail(
    val item: Item,
    val reviews: List<Review>,
    @SerialName("my_review") val myReview: MyReview? = null,
)

@Serializable
data class ServerConfig(
    val name: String = "Ratings",
    val mode: String = "private",
    @SerialName("item_submission") val itemSubmission: String = "approval",
    @SerialName("login_required_to_add") val loginRequiredToAdd: Boolean = true,
)

enum class Sort(val label: String) { Newest("Newest"), Top("Top rated"), Popular("Most reviewed") }
@Serializable data class AuthResponse(val token: String, val username: String)

enum class SubmissionResult { Published, Suggested }

sealed interface Screen {
    data object Setup : Screen
    data object Home : Screen
    data object Auth : Screen
    data object AddItem : Screen
    data class Detail(val id: Int) : Screen
}
