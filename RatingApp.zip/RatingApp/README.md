# Ratings App

An Android ratings catalogue backed by Cloudflare Workers + D1.

- `app/` — Kotlin + Jetpack Compose Android client.
- `worker/worker.js` — private-server Worker (suggestions wait for admin approval).
- `worker/public-worker.js` — standalone public community Worker (logged-in submissions publish immediately).
- `worker/schema.sql` — base database schema.
- `worker/migrations/002_community_features.sql` — one-time upgrade for an existing database.
- `worker/wrangler.toml` / `worker/wrangler-public.toml` — private/public deployment examples.
- `.github/workflows/` — Android APK build and optional Worker deploy.

## App server choices

The first screen offers:

- **Community server:** `https://public-ratings.nicelytinned.workers.dev`
- **Private server:** paste the Worker URL supplied by the private server owner.

The app reads `/api/config` to identify the server mode. Accounts are separate per server. On public servers, a signed-in user can publish an item immediately and the catalogue displays `Added by <username>`. On private servers, a signed-in user sends a suggestion to the admin queue; the contributor is retained when the admin approves it. Guests can browse and rate, but cannot add, suggest, or report content.

## Cloudflare setup: new server

1. Create a D1 database.
2. Run all of `worker/schema.sql` in the D1 Console.
3. For an older database that does not yet have `reviews.ip_hash`, also run `worker/migrations/001_add_ip_hash.sql` once.
4. Run `worker/migrations/002_community_features.sql` in the D1 Console.
5. Create a Worker and paste **all of** `worker/worker.js` for a private server, or `worker/public-worker.js` for the public community server.
6. Add a D1 binding named exactly `DB` and select the database you created.
7. Add secrets `JWT_SECRET` (long random secret) and `ADMIN_TOKEN` (private admin credential).
8. Add Worker variables:
   - Private: `SERVER_MODE=private`, `SERVER_NAME=Your Server Name`.
   - Public: `SERVER_MODE=public`, `SERVER_NAME=Community Ratings`.
9. Deploy and test the root URL. It should return JSON with `app: rating-worker` and the configured mode.
10. Open `https://YOUR-WORKER-URL/panel` to access the admin dashboard.

For a new DB, run the base schema and migration in that order. For an existing server, back up the D1 database, run the updated base schema (safe `CREATE TABLE IF NOT EXISTS` statements), then run migration `002` **once**. Do not rerun migration `002`, because SQLite's `ALTER TABLE ADD COLUMN` does not support duplicate columns. If this database predates the `ip_hash` column in `reviews`, also run `worker/migrations/001_add_ip_hash.sql` once before migration `002`.

## Phone-only deployment notes

The Cloudflare dashboard can be used from a phone browser with **Desktop site** enabled. Create the D1 database, use its Console to run the schema and migration SQL, then create a Worker using **Start with Hello World** and replace the editor contents with the complete Worker script. Add the `DB` binding and the two secrets from the steps above, then deploy. The owner can share the resulting Worker URL for private-server connections.

For APK builds, upload the updated `RatingApp.zip` to the GitHub repository, add the workflow file at `.github/workflows/android.yml` if it is not already present, then open **Actions → Android → Run workflow**. Download the APK from the build artifact or published release.

## Public community server deployment

`worker/public-worker.js` is the complete copy-and-paste public build. Deploy it to the existing community Worker URL, using the existing public D1 database if it already contains catalogue data. Back up the database first, run `schema.sql`, run migration `002` once, set `SERVER_MODE=public`, then deploy. Keep `JWT_SECRET` unchanged on an existing installation so existing login tokens/password hashes continue to work. Keep `ADMIN_TOKEN` private.

The app's community preset is already set to:

`https://public-ratings.nicelytinned.workers.dev`

That URL needs to be running this updated Worker and migrated database for public additions, tags, and moderation to work. If the existing endpoint is currently unavailable, deploying the new script at that hostname is required; connecting to a URL alone cannot install backend changes.

## Private servers

Private servers use `worker/worker.js` and `SERVER_MODE=private`. Give users the server's `https://...workers.dev` URL. Their item submissions appear in `/panel` under **Suggestions**. Admins can approve or reject each suggestion. Approving publishes the item and preserves the contributor's username.

## Moderation and tags

- Each item supports up to 8 tags; each tag is up to 24 characters.
- The Android catalogue can search item names, descriptions, and tags, and filter by tag.
- Signed-in users can report an item or review with a reason.
- `/panel` has a Reports queue. Admins can hide reported content or dismiss a report.
- Hidden items/reviews are removed from public responses. Hidden items can be restored in the Catalogue tab. Review deletion remains available through the admin API.
- Suggestions have pending, approved, and rejected states.
- Admin panel: `/panel`.

## Admin API

Use `Authorization: Bearer <ADMIN_TOKEN>`:

- `GET /admin/ping`
- `GET /admin/items`, `POST /admin/items`
- `PUT /admin/items/:id`, `DELETE /admin/items/:id`
- `GET /admin/suggestions`, `PUT /admin/suggestions/:id` with `{ "action": "approve" | "reject" }`
- `GET /admin/reports`, `PUT /admin/reports/:id` with `{ "action": "hide" | "dismiss" }`
- `GET /admin/reviews?status=hidden`, `PUT /admin/reviews/:id` with `{ "status": "published" | "hidden" }`, `DELETE /admin/reviews/:id`

## Public API

- `GET /api/config`, `GET /api/items`, `GET /api/items/:id`, `GET /api/tags`
- `POST /api/signup`, `POST /api/login`
- `POST /api/items` — authenticated; instant publish on public mode, suggestion queue on private mode
- `POST /api/items/:id/reviews`, `DELETE /api/items/:id/reviews/mine`
- `POST /api/reports` — authenticated report for an item or review

Guests can still rate. Guest reviews are limited to one review per item per day and 30 per day per hashed IP address.

## Android APK build

The GitHub Actions workflow at `.github/workflows/android.yml` builds the APK. Upload the updated `RatingApp.zip` to your repository (or commit the project files), then run the Android workflow. Unsigned CI builds use the debug key and can be installed directly for testing. Proper Play Store releases need your own signing keystore and the existing signing secrets.

## Troubleshooting

- **Server not recognized:** open the Worker root URL; it should return `{"app":"rating-worker","ok":true,...}`.
- **Database error:** check that the D1 binding is named `DB` and that both the base schema and migration `002` were applied.
- **Sign-up exceeds Worker CPU:** lower `PBKDF2_ITERATIONS` before new accounts are created; changing it later invalidates existing password hashes.
- **Existing users cannot log in after deploying:** confirm that `JWT_SECRET` and `PBKDF2_ITERATIONS` were not changed.
