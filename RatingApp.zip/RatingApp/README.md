# Rating App

- `worker/worker.js` – the whole backend in ONE file (Cloudflare Worker + D1). Includes the admin page at `/panel`.
- `worker/schema.sql` – database tables (paste into the D1 console).
- `app/` – Android app (Kotlin + Jetpack Compose).
- `.github/workflows/android.yml` – builds the APK in GitHub. `worker.yml` – optional auto-deploy for the Worker.

## Phone-only setup (no computer, no command line)

### A. Cloudflare (backend) – dash.cloudflare.com
Tip: on a phone, switch your browser to "Desktop site" – the dashboard is much easier to use.

1. **Create the database.** Storage & Databases -> D1 SQL Database -> Create database -> name it `rating-db`.
   Open it -> **Console** tab -> paste the whole of `worker/schema.sql` -> Execute.
2. **Create the Worker.** Workers & Pages -> Create application -> *Start with Hello World* -> name it
   (e.g. `rating-app`) -> Deploy.
3. **Paste the code.** On the Worker page tap **Edit code** -> select all the default code, delete it, paste
   the whole of `worker/worker.js` -> **Deploy**.
4. **Connect the database.** Worker -> **Bindings** -> Add binding -> D1 database -> variable name exactly `DB`
   -> choose `rating-db` -> Add binding.
5. **Add secrets.** Worker -> **Settings** -> Variables and Secrets -> Add. Type **Secret**, then:
   - `JWT_SECRET` = a long random string (40+ characters, mash the keyboard)
   - `ADMIN_TOKEN` = your admin password (long, keep it private)
   Then press **Deploy**.
6. **Test.** Open your Worker URL (shown on the Worker page, like `https://rating-app.NAME.workers.dev`).
   You should see `{"app":"rating-worker","ok":true}`.
7. **Add items.** Open `YOUR-URL/panel`, enter the admin token, add items (name, image URL, description).

### B. GitHub (builds the APK for you)
1. Create a new repository on github.com (private or public).
2. **Add file -> Upload files** -> pick `RatingApp.zip` (leave it zipped!) -> Commit.
3. **Add file -> Create new file** -> in the name box type `.github/workflows/android.yml`
   (typing the slashes creates the folders) -> paste the contents of `android.yml` -> Commit.
   That commit starts a build automatically.
4. **Actions** tab -> *Android* -> **Run workflow** (builds again and publishes a release with the APK).
5. Open the repo's **Releases** (right side / bottom of the main page) -> `build-1` -> tap the `.apk`
   file to download -> open it -> allow "install unknown apps" for your browser when asked.
   (Or: Actions -> the run -> Artifacts -> `RatingApp-apk`, which downloads as a zip.)

### C. Use the app
Open it, enter your Worker URL (`rating-app.NAME.workers.dev` works, https is added automatically).

## Updating later
- **Worker code changed:** Worker -> Edit code -> paste the new `worker.js` -> Deploy.
- **App changed:** upload a new `RatingApp.zip` to the repo (Add file -> Upload files, same name replaces it)
  -> it rebuilds -> Actions -> Run workflow for a new release APK.
- **Upgrading from the first versions of this project:** your D1 table needs one extra column. In the D1 console run:
  `ALTER TABLE reviews ADD COLUMN ip_hash TEXT;`

## Optional: proper signed releases
Debug-signed APKs install fine on your own phone. For a stable signature (needed for Play Store / seamless
updates), generate a keystore (needs a computer or an Android terminal app), and add repo secrets
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Releases from tags (`v1.0.0`) are
then signed automatically.

## Optional: auto-deploy the Worker from GitHub
`worker.yml` deploys on every push that changes `worker/`. It requires the project files to be in the repo
(not just the zip), the real `database_id` in `wrangler.toml`, repo secrets `CLOUDFLARE_API_TOKEN`,
`CLOUDFLARE_ACCOUNT_ID`, `JWT_SECRET`, `ADMIN_TOKEN`, and a repo variable `DEPLOY_WORKER=true`.

## Admin API (alternative to /panel)
`Authorization: Bearer <ADMIN_TOKEN>` -> `POST /admin/items`, `PUT /admin/items/:id`,
`DELETE /admin/items/:id`, `DELETE /admin/reviews/:id`.

## Public API
`GET /api/items`, `GET /api/items/:id`, `POST /api/items/:id/reviews`, `DELETE /api/items/:id/reviews/mine`,
`POST /api/signup`, `POST /api/login`.
Guests: 1 review per item per day, 30 per day per (hashed) IP.

## Troubleshooting
- *App says "doesn't look like the rating server"* – URL wrong, or the Worker isn't deployed. Open it in the browser first.
- *"Server error (500)"* – usually the `DB` binding or a secret is missing/misspelled. Worker -> Observability/Logs shows the error.
- *Sign-up fails with "exceeded CPU"* – on the free Workers plan, lower `PBKDF2_ITERATIONS` at the top of `worker.js`
  (e.g. 20000) before anyone signs up, and redeploy.
- *GitHub build fails* – Actions -> the failed run -> open the red step; most often the zip wasn't uploaded as `RatingApp.zip`.
