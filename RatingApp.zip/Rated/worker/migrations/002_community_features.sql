-- Run once on an existing D1 database after schema.sql.
-- This adds columns without rewriting existing catalogue/review data.
ALTER TABLE items ADD COLUMN added_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE items ADD COLUMN added_by TEXT NOT NULL DEFAULT 'Admin';
ALTER TABLE items ADD COLUMN status TEXT NOT NULL DEFAULT 'published';
ALTER TABLE reviews ADD COLUMN status TEXT NOT NULL DEFAULT 'published';
CREATE INDEX IF NOT EXISTS items_status ON items(status);
CREATE INDEX IF NOT EXISTS reviews_status ON reviews(status);
