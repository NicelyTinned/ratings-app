-- Base schema. Run this first for both new and existing D1 databases.
-- Existing installs keep their data; CREATE TABLE IF NOT EXISTS is safe.
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  image_url TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  author TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 10),
  text TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  ip_hash TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS one_review_per_user ON reviews(item_id, user_id) WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS reviews_item ON reviews(item_id);

-- Tags are shared across catalogue items.
CREATE TABLE IF NOT EXISTS tags (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE
);
CREATE TABLE IF NOT EXISTS item_tags (
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (item_id, tag_id)
);
CREATE INDEX IF NOT EXISTS item_tags_tag ON item_tags(tag_id);

-- Private-server proposals wait here until an admin approves or rejects them.
CREATE TABLE IF NOT EXISTS item_suggestions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  image_url TEXT NOT NULL DEFAULT '',
  tags_json TEXT NOT NULL DEFAULT '[]',
  suggested_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  suggested_by TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at INTEGER NOT NULL,
  reviewed_at INTEGER,
  reviewed_by TEXT,
  item_id INTEGER REFERENCES items(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS suggestions_status_created ON item_suggestions(status, created_at);

-- Reports are queued for an admin; hide is reversible, dismiss keeps content visible.
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  target_type TEXT NOT NULL CHECK (target_type IN ('item', 'review')),
  target_id INTEGER NOT NULL,
  reporter_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reporter TEXT NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'dismissed', 'actioned')),
  created_at INTEGER NOT NULL,
  reviewed_at INTEGER
);
CREATE INDEX IF NOT EXISTS reports_status_created ON reports(status, created_at);
CREATE INDEX IF NOT EXISTS reports_target ON reports(target_type, target_id);
