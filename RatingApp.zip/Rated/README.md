# Rated

Rated is an Android ratings catalogue backed by Cloudflare Workers and D1.

## Android app

- `app/` — Kotlin + Jetpack Compose client with a custom dark visual theme, gradients, and the supplied Rated logo.
- The launcher label and app branding are **Rated**.
- The existing Android application ID is intentionally retained as `com.example.ratingapp` so an installed earlier build can be upgraded instead of requiring an uninstall.
- Private/custom servers are saved on the device after a successful connection. Rated reads each server's display name from `/api/config`, stores it with the URL, and shows saved servers on the setup screen. Tap a saved server to reconnect or tap `×` to remove it.
- Saved server names and URLs are stored locally in Android SharedPreferences. Removing a server also records that choice so the active server is not silently re-added during refresh or app restart. Connecting to it again explicitly saves it again.
- Login credentials remain separate per currently selected server, matching the previous app behavior.

## Server choices

- **Community server:** `https://public-ratings.nicelytinned.workers.dev`
- **Private/custom server:** enter the Worker URL supplied by its owner. After the connection check succeeds, Rated fetches its configured server name and adds it to the saved list.

Accounts are separate per server. On public servers, a signed-in user can publish an item immediately and the catalogue displays `Added by <username>`. On private servers, a signed-in user sends a suggestion to the admin queue; the contributor is retained when the admin approves it. Guests can browse and rate, but cannot add, suggest, or report content.

## Cloudflare setup: new server

1. Create a D1 database.
2. Run all of `worker/schema.sql` in the D1 Console.
3. For an older database that does not yet have `reviews.ip_hash`, also run `worker/migrations/001_add_ip_hash.sql` once.
4. Run `worker/migrations/002_community_features.sql` in the D1 Console.
5. Create a Worker and paste **all of** `worker/worker.js` for a private server, or `worker/public-worker.js` for the public community server.
6. Add a D1 binding named exactly `DB` and select the database you created.
7. Add secrets `JWT_SECRET` (long random secret) and `ADMIN_TOKEN` (private admin credential).
8. Add Worker variables:
   - Private: `SERVER_MODE=private`, `SERVER_NAME=Your Server Name`.
   - Public: `SERVER_MODE=public`, `SERVER_NAME=Community Ratings`.
9. Deploy and test the root URL. It should return JSON with `app: rating-worker` and the configured mode.
10. Open `https://YOUR-WORKER-URL/panel` to access the admin dashboard.

For a new DB, run the base schema and migration in that order. For an existing server, back up the D1 database, run the updated base schema (safe `CREATE TABLE IF NOT EXISTS` statements), then run migration `002` **once**. Do not rerun migration `002`, because SQLite's `ALTER TABLE ADD COLUMN` does not support duplicate columns. If this database predates the `ip_hash` column in `reviews`, also run `worker/migrations/001_add_ip_hash.sql` once before migration `002`.

## Private servers

Private servers use `worker/worker.js` and `SERVER_MODE=private`. Give users the server's `https://...workers.dev` URL. Their item submissions appear in `/panel` under **Suggestions**. Admins can approve or reject each suggestion. Approving publishes the item and preserves the contributor's username.

## Moderation and tags

- Each item supports up to 8 tags; each tag is up to 24 characters.
- The Android catalogue can search item names, descriptions, and tags, and filter by tag.
- Signed-in users can report an item or review with a reason.
- `/panel` has a Reports queue. Admins can hide reported content or dismiss a report.
- Hidden items/reviews are removed from public responses. Hidden items can be restored in the Catalogue tab.
- Suggestions have pending, approved, and rejected states.
- Admin panel: `/panel`.

## Public API

- `GET /api/config`, `GET /api/items`, `GET /api/items/:id`, `GET /api/tags`
- `POST /api/signup`, `POST /api/login`
- `POST /api/items` — authenticated; instant publish on public mode, suggestion queue on private mode
- `POST /api/items/:id/reviews`, `DELETE /api/items/:id/reviews/mine`
- `POST /api/reports` — authenticated report for an item or review

## Android APK build

The GitHub Actions workflow at `.github/workflows/android.yml` builds the APK. Upload `Rated.zip` to your GitHub repository, then open **Actions → Rated Android → Run workflow**. Download the APK from the build artifact or published release. The workflow also accepts the previous archive name `RatingApp.zip`.

Unsigned CI builds use the debug key and can be installed directly for testing. Proper Play Store releases need your own signing keystore and the existing signing secrets.

## Public community server deployment

`worker/public-worker.js` is the complete copy-and-paste public build. Deploy it to the existing community Worker URL, using the existing public D1 database if it already contains catalogue data. Back up the database first, run `schema.sql`, run migration `002` once, set `SERVER_MODE=public`, then deploy. Keep `JWT_SECRET` unchanged on an existing installation so existing login tokens/password hashes continue to work. Keep `ADMIN_TOKEN` private.

The app's community preset is `https://public-ratings.nicelytinned.workers.dev`. That URL needs to be running the updated Worker and migrated database for public additions, tags, and moderation to work.
