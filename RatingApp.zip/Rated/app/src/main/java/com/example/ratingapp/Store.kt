package com.example.ratingapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("rating_app", Context.MODE_PRIVATE)

    var baseUrl: String?
        get() = p.getString("url", null)
        set(v) { p.edit().putString("url", v).apply() }

    var token: String?
        get() = p.getString("token", null)
        set(v) { p.edit().putString("token", v).apply() }

    var username: String?
        get() = p.getString("username", null)
        set(v) { p.edit().putString("username", v).apply() }

    var savedServers: List<SavedServer>
        get() {
            val raw = p.getString("saved_servers", "[]") ?: "[]"
            return runCatching {
                val array = JSONArray(raw)
                buildList {
                    for (i in 0 until array.length()) {
                        val item = array.getJSONObject(i)
                        val name = item.optString("name").trim()
                        val url = item.optString("url").trim()
                        if (name.isNotBlank() && url.isNotBlank()) add(SavedServer(name, url))
                    }
                }
            }.getOrDefault(emptyList())
        }
        set(value) {
            val array = JSONArray()
            value.distinctBy { it.url.lowercase() }.forEach { server ->
                array.put(JSONObject().put("name", server.name).put("url", server.url))
            }
            p.edit().putString("saved_servers", array.toString()).apply()
        }

    private val removedServers: Set<String>
        get() = p.getStringSet("removed_servers", emptySet())?.map { it.lowercase() }?.toSet() ?: emptySet()

    fun rememberServer(server: SavedServer) {
        val removed = removedServers.toMutableSet()
        removed.remove(server.url.lowercase())
        p.edit().putStringSet("removed_servers", removed).apply()
        savedServers = savedServers.filterNot { it.url.equals(server.url, true) } + server
    }

    fun addLegacyServerIfNotRemoved(server: SavedServer) {
        if (server.url.lowercase() !in removedServers && savedServers.none { it.url.equals(server.url, true) }) {
            savedServers = savedServers + server
        }
    }

    fun updateServerNameIfSaved(server: SavedServer) {
        val existing = savedServers.firstOrNull { it.url.equals(server.url, true) } ?: return
        if (existing.name != server.name) {
            savedServers = savedServers.map { if (it.url.equals(server.url, true)) server else it }
        }
    }

    fun removeServer(url: String) {
        val removed = removedServers.toMutableSet()
        removed.add(url.lowercase())
        p.edit().putStringSet("removed_servers", removed).apply()
        savedServers = savedServers.filterNot { it.url.equals(url, true) }
    }
}
