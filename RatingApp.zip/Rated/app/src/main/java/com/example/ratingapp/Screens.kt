@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.ratingapp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private val Gold = Color(0xFFFFC857)
private val Violet = Color(0xFF9B8CFF)
private val Panel = Color(0xFF171B2E)
private val PanelRaised = Color(0xFF202640)
private val Line = Color(0xFF525A80).copy(alpha = 0.42f)
private val Muted = Color(0xFFADB4D0)

private fun fmt(d: Double) = String.format(Locale.US, "%.1f", d)

@Composable
private fun RatedBackdrop(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(listOf(Color(0xFF0B0D18), Color(0xFF11152A), Color(0xFF0D1020))))
            .drawBehind {
                drawCircle(Color(0xFF5146A8).copy(alpha = 0.19f), size.minDimension * 0.62f, Offset(size.width * 0.98f, size.height * 0.08f))
                drawCircle(Color(0xFFB98039).copy(alpha = 0.075f), size.minDimension * 0.48f, Offset(size.width * 0.02f, size.height * 0.76f))
            },
        content = content,
    )
}

@Composable
private fun BrandLockup(compact: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
        ImageLogo(if (compact) 38.dp else 54.dp)
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("Rated", style = if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = Color.White)
            Text("Ratings and reviews", style = MaterialTheme.typography.labelSmall, color = Muted)
        }
    }
}

@Composable
private fun ImageLogo(size: androidx.compose.ui.unit.Dp) {
    Image(
        painter = painterResource(R.drawable.rated_mark),
        contentDescription = "Rated logo",
        contentScale = ContentScale.Fit,
        modifier = Modifier.size(size).clip(RoundedCornerShape(size / 3)).background(Color(0xFF0B0D18)),
    )
}

@Composable
private fun ErrorText(msg: String?) {
    if (msg != null) Text(msg, color = Color(0xFFFF8998), modifier = Modifier.padding(vertical = 4.dp), style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun NoticeText(msg: String?) {
    if (msg != null) {
        Surface(color = Color(0xFF233C3A), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Color(0xFF3E7770))) {
            Text(msg, Modifier.fillMaxWidth().padding(12.dp), color = Color(0xFFBDF3E7), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun RatingBadge(item: Item) {
    if (item.reviewCount == 0) {
        Surface(color = PanelRaised, shape = RoundedCornerShape(10.dp)) {
            Text("NOT RATED YET", Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelSmall, color = Muted, fontWeight = FontWeight.Bold)
        }
    } else {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(color = Gold, shape = RoundedCornerShape(10.dp)) {
                Text("★ ${fmt(item.avgRating)}", Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Color(0xFF211A0D), fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelLarge)
            }
            Text("/ 10  ·  ${item.reviewCount} review${if (item.reviewCount == 1) "" else "s"}", style = MaterialTheme.typography.labelMedium, color = Muted)
        }
    }
}

@Composable
private fun ItemImage(url: String, modifier: Modifier = Modifier) {
    val imageModifier = modifier.aspectRatio(16 / 9f).clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(Color(0xFF292D4B), Color(0xFF171B2E))))
    if (url.isBlank()) {
        Box(imageModifier, contentAlignment = Alignment.Center) {
            Text("Rated", style = MaterialTheme.typography.labelLarge, color = Color(0xFF8E91B7), fontWeight = FontWeight.Bold)
        }
    } else {
        AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = imageModifier)
    }
}

@Composable
private fun TagsRow(tags: List<String>, compact: Boolean = false) {
    if (tags.isNotEmpty()) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            tags.forEach { tag ->
                Surface(color = Color(0xFF292A4C), shape = RoundedCornerShape(999.dp), border = BorderStroke(1.dp, Color(0xFF59538C))) {
                    Text("#${tag}", Modifier.padding(horizontal = if (compact) 9.dp else 11.dp, vertical = if (compact) 4.dp else 6.dp), color = Color(0xFFD2CCFF), style = if (compact) MaterialTheme.typography.labelSmall else MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun SectionHeading(title: String, detail: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Color.White)
        if (detail != null) Text(detail, style = MaterialTheme.typography.bodySmall, color = Muted)
    }
}

@Composable
private fun ServerTile(server: SavedServer, active: Boolean, loading: Boolean, onOpen: () -> Unit, onDelete: () -> Unit) {
    Surface(
        color = if (active) Color(0xFF282648) else Panel,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, if (active) Violet.copy(alpha = 0.75f) else Line),
        modifier = Modifier.fillMaxWidth().clickable(enabled = !loading, onClick = onOpen),
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 8.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFF34345E)), contentAlignment = Alignment.Center) {
                Text("↗", color = Color(0xFFCFC8FF), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(server.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(server.url, style = MaterialTheme.typography.bodySmall, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (active) {
                Text("ACTIVE", color = Color(0xFFC5BDFF), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 6.dp))
            }
            TextButton(onClick = onDelete, enabled = !loading, contentPadding = PaddingValues(horizontal = 8.dp)) {
                Text("×", color = Color(0xFFFF9AA5), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Normal)
            }
        }
    }
}

@Composable
private fun PrimaryAction(text: String, enabled: Boolean = true, loading: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Color(0xFF17132F), disabledContainerColor = Color(0xFF47465E)),
    ) {
        if (loading) CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp, color = Color.White)
        else Text(text, fontWeight = FontWeight.ExtraBold)
    }
}

// ---------------- Server setup ----------------
@Composable
fun SetupScreen(vm: AppVM) {
    var url by remember { mutableStateOf("") }

    RatedBackdrop {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 21.dp, vertical = 25.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            BrandLockup()
            Spacer(Modifier.height(3.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Your servers", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, color = Color.White, lineHeight = 43.sp)
                Text("Choose a server to browse ratings and reviews.", style = MaterialTheme.typography.bodyLarge, color = Muted)
            }

            Surface(
                color = Color.Transparent,
                shape = RoundedCornerShape(25.dp),
                border = BorderStroke(1.dp, Color(0xFF7D70DB).copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    Modifier.background(Brush.linearGradient(listOf(Color(0xFF332F68), Color(0xFF202440), Color(0xFF1A2034)))).padding(19.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("✦", color = Gold, style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.width(9.dp))
                        Text("THE COMMUNITY", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.weight(1f))
                        Surface(color = Color(0xFF3B745E), shape = RoundedCornerShape(999.dp)) {
                            Text("PUBLIC", Modifier.padding(horizontal = 10.dp, vertical = 5.dp), color = Color(0xFFD5FFE5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("One shared catalogue for everyone. Sign in to add entries and get credit for your contributions.", color = Color(0xFFD0D2E9), style = MaterialTheme.typography.bodyMedium)
                    PrimaryAction("Enter community", enabled = !vm.loading, loading = vm.loading) { vm.connect(AppVM.PUBLIC_SERVER_URL) }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeading("Your saved servers", "Custom servers are saved here after a successful connection.")
                if (vm.savedServers.isEmpty()) {
                    Surface(color = Panel.copy(alpha = 0.84f), shape = RoundedCornerShape(17.dp), border = BorderStroke(1.dp, Line)) {
                        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("◎", color = Violet, style = MaterialTheme.typography.headlineMedium)
                            Spacer(Modifier.width(12.dp))
                            Text("No custom servers saved yet. Connect to one below and Rated will remember its name and address.", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                } else {
                    vm.savedServers.forEach { server ->
                        ServerTile(
                            server = server,
                            active = server.url.equals(vm.baseUrl, true),
                            loading = vm.loading,
                            onOpen = { vm.connectSaved(server) },
                            onDelete = { vm.removeSavedServer(server) },
                        )
                    }
                }
            }

            Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Line)) {
                Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                    Text("Add a custom server", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.ExtraBold)
                    Text("Paste its URL. Rated checks the server, reads its display name, then saves both for next time.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it },
                        label = { Text("Server URL") },
                        placeholder = { Text("https://readly.name.workers.dev") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { vm.connect(url) }),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Violet,
                            unfocusedBorderColor = Color(0xFF454B6A),
                            focusedLabelColor = Violet,
                            unfocusedLabelColor = Muted,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = Violet,
                        ),
                    )
                    PrimaryAction("Connect & save", enabled = !vm.loading && url.isNotBlank(), loading = vm.loading) { vm.connect(url) }
                }
            }
            ErrorText(vm.error)
            NoticeText(vm.notice)
            Text("Accounts and reviews are separate on each server. Server URLs are provided by their owners.", color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

// ---------------- Catalogue ----------------
@Composable
fun HomeScreen(vm: AppVM) {
    var menu by remember { mutableStateOf(false) }

    RatedBackdrop {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ImageLogo(35.dp)
                            Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                                Text("Rated", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                                Text(vm.serverConfig?.name ?: "Your catalogue", color = Muted, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    },
                    actions = {
                        if (vm.token != null) IconButton(onClick = { vm.go(Screen.AddItem) }) { Icon(Icons.Default.Add, "Add item", tint = Gold) }
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu", tint = Color.White) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            if (vm.token == null) {
                                DropdownMenuItem(text = { Text("Log in / Sign up") }, onClick = { menu = false; vm.go(Screen.Auth) })
                            } else {
                                DropdownMenuItem(text = { Text("Log out") }, onClick = { menu = false; vm.logout() })
                            }
                            DropdownMenuItem(text = { Text("Manage servers") }, onClick = { menu = false; vm.go(Screen.Setup) })
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                )
            },
        ) { pad ->
            PullToRefreshBox(isRefreshing = vm.loading, onRefresh = { vm.refresh() }, modifier = Modifier.padding(pad).fillMaxSize()) {
                LazyColumn(contentPadding = PaddingValues(horizontal = 17.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(25.dp)).background(Brush.linearGradient(listOf(Color(0xFF373164), Color(0xFF232944), Color(0xFF20253B)))).padding(19.dp),
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Text("Catalogue", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                                    Text("Browse entries and community ratings.", color = Color(0xFFD2D4E8), style = MaterialTheme.typography.bodyMedium)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Surface(color = Color(0xFF141A2C).copy(alpha = 0.7f), shape = RoundedCornerShape(999.dp)) {
                                            Text("${vm.items.size} entries", Modifier.padding(horizontal = 11.dp, vertical = 6.dp), color = Color.White, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                        }
                                        Surface(color = Color(0xFF141A2C).copy(alpha = 0.7f), shape = RoundedCornerShape(999.dp)) {
                                            Text(vm.serverConfig?.mode?.uppercase() ?: "SERVER", Modifier.padding(horizontal = 11.dp, vertical = 6.dp), color = Color(0xFFD3CCFF), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                            OutlinedTextField(
                                value = vm.query,
                                onValueChange = { vm.query = it },
                                placeholder = { Text("Search names, descriptions, tags…") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Violet,
                                    unfocusedBorderColor = Line,
                                    focusedContainerColor = Panel,
                                    unfocusedContainerColor = Panel,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    cursorColor = Violet,
                                ),
                            )
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Sort.entries.forEach { s ->
                                    FilterChip(
                                        selected = vm.sort == s,
                                        onClick = { vm.sort = s },
                                        label = { Text(s.label) },
                                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF514A86), selectedLabelColor = Color.White, labelColor = Muted)
                                    )
                                }
                            }
                            if (vm.availableTags.isNotEmpty()) {
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    FilterChip(selected = vm.selectedTag == null, onClick = { vm.selectedTag = null }, label = { Text("All tags") }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF514A86), selectedLabelColor = Color.White, labelColor = Muted))
                                    vm.availableTags.forEach { tag ->
                                        FilterChip(selected = vm.selectedTag == tag, onClick = { vm.selectedTag = if (vm.selectedTag == tag) null else tag }, label = { Text("#$tag") }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF514A86), selectedLabelColor = Color.White, labelColor = Muted))
                                    }
                                }
                            }
                            NoticeText(vm.notice)
                            ErrorText(vm.error)
                            if (vm.token != null) {
                                PrimaryAction(if (vm.serverConfig?.mode == "public") "＋  Add to community" else "＋  Suggest an entry", enabled = !vm.loading, loading = vm.loading) { vm.go(Screen.AddItem) }
                            } else {
                                TextButton(onClick = { vm.go(Screen.Auth) }) { Text("Log in to add or suggest an entry", color = Violet, fontWeight = FontWeight.Bold) }
                            }
                            SectionHeading("The catalogue", "Tap an entry to see its ratings and reviews.")
                        }
                    }
                    val shown = vm.visibleItems
                    when {
                        vm.items.isEmpty() && vm.loading -> item {
                            Box(Modifier.fillMaxWidth().padding(vertical = 42.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Violet) }
                        }
                        shown.isEmpty() -> item {
                            Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Line)) {
                                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    Text("✦", color = Gold, style = MaterialTheme.typography.displaySmall)
                                    Text(if (vm.items.isEmpty()) "a blank canvas." else "nothing found.", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                    Text(if (vm.items.isEmpty()) "The catalogue is waiting for its first entry." else "Try another search or clear the tag filter.", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    if (vm.items.isEmpty() && vm.token != null) TextButton(onClick = { vm.go(Screen.AddItem) }) { Text("Add the first entry", color = Violet) }
                                    TextButton(onClick = { vm.refresh() }) { Text("Refresh", color = Muted) }
                                }
                            }
                        }
                        else -> items(shown, key = { it.id }) { entry ->
                            Surface(
                                color = Panel,
                                shape = RoundedCornerShape(23.dp),
                                border = BorderStroke(1.dp, Line),
                                modifier = Modifier.fillMaxWidth().clickable { vm.openItem(entry.id) },
                            ) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    ItemImage(entry.imageUrl, Modifier.fillMaxWidth())
                                    Text(entry.name, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    RatingBadge(entry)
                                    if (entry.description.isNotBlank()) Text(entry.description, color = Color(0xFFC3C8DD), maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                                    TagsRow(entry.tags, compact = true)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("ADDED BY", color = Color(0xFF858BAA), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                        Spacer(Modifier.width(6.dp))
                                        Text(entry.addedBy, color = Color(0xFFD0CCFF), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- Add / suggest item ----------------
@Composable
fun AddItemScreen(vm: AppVM) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var image by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }
    val isPublic = vm.serverConfig?.mode == "public"

    RatedBackdrop {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text(if (isPublic) "New entry" else "Suggest an entry", color = Color.White, fontWeight = FontWeight.Bold) },
                    navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                )
            },
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(19.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Surface(color = Color(0xFF252344), shape = RoundedCornerShape(21.dp), border = BorderStroke(1.dp, Color(0xFF61579B))) {
                    Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(if (isPublic) "put it on the map." else "send it to the mods.", style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Black)
                        Text(if (isPublic) "Your entry goes live immediately, with your username shown as its contributor." else "Your suggestion goes into the server's approval queue. Your username stays attached if it is approved.", color = Color(0xFFD1D2E8), style = MaterialTheme.typography.bodyMedium)
                        Text("SUBMITTING AS  ${vm.username ?: "GUEST"}", color = Gold, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    }
                }
                RatedField(name, { name = it }, "Entry name", "What are we rating?", oneLine = true)
                RatedField(description, { description = it }, "Description", "A little context helps.", oneLine = false, minLines = 3)
                RatedField(image, { image = it }, "Image URL · optional", "https://…", oneLine = true, keyboardType = KeyboardType.Uri)
                RatedField(tags, { tags = it }, "Tags", "books, cozy, sci-fi", oneLine = true, supporting = "Separate with commas. Up to 8 tags.")
                ErrorText(vm.error)
                PrimaryAction(if (isPublic) "Publish entry" else "Send suggestion", enabled = !vm.loading && name.isNotBlank(), loading = vm.loading) { vm.addItem(name, description, image, tags) }
                TextButton(onClick = { vm.back() }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Cancel", color = Muted) }
            }
        }
    }
}

@Composable
private fun RatedField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    oneLine: Boolean,
    minLines: Int = 1,
    keyboardType: KeyboardType = KeyboardType.Text,
    supporting: String? = null,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        singleLine = oneLine,
        minLines = minLines,
        supportingText = if (supporting == null) null else { { Text(supporting) } },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(15.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Violet,
            unfocusedBorderColor = Line,
            focusedLabelColor = Violet,
            unfocusedLabelColor = Muted,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            cursorColor = Violet,
        ),
    )
}

// ---------------- Authentication ----------------
@Composable
fun AuthScreen(vm: AppVM) {
    var login by remember { mutableStateOf(true) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    RatedBackdrop {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text(if (login) "Welcome back" else "Join the server", color = Color.White, fontWeight = FontWeight.Bold) },
                    navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                )
            },
        ) { pad ->
            Column(Modifier.padding(pad).padding(horizontal = 21.dp, vertical = 15.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                ImageLogo(62.dp)
                Text(if (login) "your account,\nyour corner." else "make it official.", style = MaterialTheme.typography.headlineLarge, color = Color.White, fontWeight = FontWeight.Black, lineHeight = 39.sp)
                Text("Accounts are separate for each server. New passwords must be at least 8 characters.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                RatedField(user, { user = it }, "Username", "3–20 letters, numbers or _", oneLine = true)
                OutlinedTextField(
                    value = pass,
                    onValueChange = { pass = it },
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { vm.auth(login, user, pass) }),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Violet, unfocusedBorderColor = Line, focusedLabelColor = Violet, unfocusedLabelColor = Muted, focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Violet),
                )
                ErrorText(vm.error)
                PrimaryAction(if (login) "Log in" else "Create account", enabled = !vm.loading && user.isNotBlank() && pass.isNotEmpty(), loading = vm.loading) { vm.auth(login, user, pass) }
                TextButton(onClick = { login = !login; vm.clearError() }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text(if (login) "New here? Create an account" else "Already have an account? Log in", color = Violet, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = { vm.back() }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Continue as guest", color = Muted) }
            }
        }
    }
}

// ---------------- Item detail / reviews / reports ----------------
@Composable
private fun StarPicker(value: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth()) {
        for (i in 1..10) {
            Icon(
                Icons.Filled.Star,
                contentDescription = "$i rating",
                tint = if (i <= value) Gold else Color(0xFF444A65),
                modifier = Modifier.weight(1f).height(31.dp).clickable { onChange(i) },
            )
        }
    }
}

@Composable
private fun Histogram(reviews: List<Review>) {
    val counts = IntArray(11)
    reviews.forEach { counts[it.rating.coerceIn(1, 10)]++ }
    val max = counts.max().coerceAtLeast(1)
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        for (score in 10 downTo 1) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$score", Modifier.width(22.dp), color = Muted, style = MaterialTheme.typography.labelSmall)
                Box(Modifier.weight(1f).height(8.dp).clip(CircleShape).background(Color(0xFF323852))) {
                    Box(Modifier.fillMaxWidth(counts[score] / max.toFloat()).fillMaxHeight().background(Brush.horizontalGradient(listOf(Gold, Color(0xFFFF9C54)))))
                }
                Text("${counts[score]}", Modifier.width(28.dp).padding(start = 6.dp), color = Muted, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun DetailScreen(vm: AppVM, id: Int) {
    val d = vm.detail
    var rating by remember { mutableIntStateOf(0) }
    var text by remember { mutableStateOf("") }
    var reportType by remember { mutableStateOf<String?>(null) }
    var reportId by remember { mutableIntStateOf(0) }
    var reportReason by remember { mutableStateOf("") }

    LaunchedEffect(d?.myReview) {
        rating = d?.myReview?.rating ?: 0
        text = d?.myReview?.text ?: ""
    }

    RatedBackdrop {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text(d?.item?.name ?: "Entry", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White) },
                    navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                )
            },
        ) { pad ->
            if (d == null) {
                Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                    if (vm.error != null) ErrorText(vm.error) else CircularProgressIndicator(color = Violet)
                }
            } else {
                val signedIn = vm.token != null
                val mine = d.myReview
                LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    item {
                        Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Line)) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                ItemImage(d.item.imageUrl, Modifier.fillMaxWidth())
                                Text(d.item.name, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                RatingBadge(d.item)
                                Text("ADDED BY  ${d.item.addedBy}", color = Muted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                TagsRow(d.item.tags)
                                if (d.item.description.isNotBlank()) Text(d.item.description, color = Color(0xFFD0D3E6), style = MaterialTheme.typography.bodyLarge)
                                if (signedIn) TextButton(onClick = { reportType = "item"; reportId = id }) { Text("Report this entry", color = Color(0xFFFF9AA5)) }
                            }
                        }
                    }
                    if (d.reviews.isNotEmpty()) item {
                        Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, Line)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                                Text("Rating breakdown", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Histogram(d.reviews)
                            }
                        }
                    }
                    item {
                        Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, Line)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(if (mine != null) "Your review" else "Drop a rating", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                Text(if (signedIn) "POSTING AS ${vm.username}" else "POSTING AS GUEST · LOG IN TO EDIT LATER", color = Muted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                StarPicker(rating) { rating = it }
                                Text(if (rating == 0) "Tap a star to choose your score" else "$rating / 10", color = Gold, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                RatedField(text, { text = it }, "Your review · optional", "What did you think?", oneLine = false, minLines = 2)
                                ErrorText(vm.error)
                                NoticeText(vm.notice)
                                PrimaryAction(if (mine != null) "Update review" else "Submit review", enabled = !vm.loading && rating > 0, loading = vm.loading) {
                                    vm.submitReview(id, rating, text) { if (!signedIn) { rating = 0; text = "" } }
                                }
                                if (mine != null) TextButton(onClick = { vm.deleteMyReview(id) }, enabled = !vm.loading) { Text("Delete my review", color = Color(0xFFFF9AA5)) }
                            }
                        }
                    }
                    item { SectionHeading("Community reviews", "${d.reviews.size} review${if (d.reviews.size == 1) "" else "s"}") }
                    items(d.reviews, key = { it.id }) { review ->
                        Surface(color = Panel, shape = RoundedCornerShape(17.dp), border = BorderStroke(1.dp, Line)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(review.author, color = Color.White, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.width(9.dp))
                                    Text("★ ${review.rating}/10", color = Gold, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.weight(1f))
                                    Text(DateFormat.getDateInstance().format(Date(review.createdAt * 1000)), color = Muted, style = MaterialTheme.typography.labelSmall)
                                }
                                if (review.text.isNotBlank()) Text(review.text, color = Color(0xFFD0D3E6), style = MaterialTheme.typography.bodyMedium)
                                if (signedIn) TextButton(onClick = { reportType = "review"; reportId = review.id }) { Text("Report review", color = Color(0xFFFF9AA5)) }
                            }
                        }
                    }
                }
            }
        }
    }

    if (reportType != null) {
        AlertDialog(
            onDismissRequest = { reportType = null; reportReason = "" },
            title = { Text("Report ${if (reportType == "item") "entry" else "review"}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tell the server moderators what needs attention.")
                    OutlinedTextField(reportReason, { reportReason = it }, label = { Text("Reason") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val type = reportType ?: return@TextButton
                        vm.reportContent(type, reportId, reportReason)
                        reportType = null
                        reportReason = ""
                    },
                    enabled = reportReason.isNotBlank() && !vm.loading,
                ) { Text("Send report") }
            },
            dismissButton = { TextButton(onClick = { reportType = null; reportReason = "" }) { Text("Cancel") } },
        )
    }
}
