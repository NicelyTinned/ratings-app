package com.example.ratingapp

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.net.URI

class AppVM(app: Application) : AndroidViewModel(app) {
    companion object {
        const val PUBLIC_SERVER_URL = "https://public-ratings.nicelytinned.workers.dev"
    }

    private val store = Store(app)

    var baseUrl by mutableStateOf(store.baseUrl)
    var token by mutableStateOf(store.token)
    var username by mutableStateOf(store.username)
    var serverConfig by mutableStateOf<ServerConfig?>(null)
    var savedServers by mutableStateOf(store.savedServers)
    var items by mutableStateOf<List<Item>>(emptyList())
    var detail by mutableStateOf<ItemDetail?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var notice by mutableStateOf<String?>(null)
    var query by mutableStateOf("")
    var selectedTag by mutableStateOf<String?>(null)
    var sort by mutableStateOf(Sort.Newest)
    var screen by mutableStateOf<Screen>(if (store.baseUrl == null) Screen.Setup else Screen.Home)

    private var api: Api? = store.baseUrl?.let { Api(it) { token } }

    val canGoBack get() = screen !is Screen.Home && !(screen is Screen.Setup && baseUrl == null)
    val availableTags: List<String> get() = items.flatMap { it.tags }.distinctBy { it.lowercase() }.sortedBy { it.lowercase() }

    val visibleItems: List<Item>
        get() {
            val q = query.trim()
            val searched = if (q.isEmpty()) items else items.filter {
                it.name.contains(q, true) || it.description.contains(q, true) || it.tags.any { tag -> tag.contains(q, true) }
            }
            val filtered = selectedTag?.let { tag -> searched.filter { item -> item.tags.any { it.equals(tag, true) } } } ?: searched
            return when (sort) {
                Sort.Newest -> filtered.sortedByDescending { it.id }
                Sort.Top -> filtered.sortedWith(compareByDescending<Item> { it.avgRating }.thenByDescending { it.reviewCount })
                Sort.Popular -> filtered.sortedByDescending { it.reviewCount }
            }
        }

    init {
        val current = store.baseUrl
        if (current != null && !current.equals(PUBLIC_SERVER_URL, true)) {
            store.addLegacyServerIfNotRemoved(SavedServer(serverLabel(current), current))
            savedServers = store.savedServers
        }
        if (api != null) refresh()
    }

    private fun serverLabel(url: String): String = runCatching {
        URI(url).host?.removePrefix("www.") ?: url
    }.getOrDefault(url)

    private fun rememberServer(url: String, config: ServerConfig) {
        if (url.equals(PUBLIC_SERVER_URL, true)) return
        val name = config.name.trim().ifBlank { serverLabel(url) }
        store.rememberServer(SavedServer(name, url))
        savedServers = store.savedServers
    }

    private fun updateSavedServerName(url: String, config: ServerConfig) {
        if (url.equals(PUBLIC_SERVER_URL, true)) return
        val name = config.name.trim().ifBlank { serverLabel(url) }
        store.updateServerNameIfSaved(SavedServer(name, url))
        savedServers = store.savedServers
    }

    private fun launch(block: suspend () -> Unit) = viewModelScope.launch {
        loading = true
        error = null
        notice = null
        try {
            block()
        } catch (e: ApiException) {
            if (e.code == 401 && token != null) { logout(); error = e.message } else error = e.message
        } catch (e: Exception) {
            error = e.message ?: "Something went wrong"
        } finally {
            loading = false
        }
    }

    private fun requireApi() = api ?: throw ApiException("Not connected to a server")

    fun go(s: Screen) { error = null; notice = null; screen = s }
    fun back() { go(Screen.Home) }
    fun clearError() { error = null }

    fun connect(raw: String) = launch {
        val url = normalizeUrl(raw) ?: throw ApiException("Please enter a valid server URL")
        val a = Api(url) { token }
        a.ping()
        val config = a.config()
        if (url != baseUrl) {
            store.token = null; store.username = null
            token = null; username = null
            items = emptyList(); detail = null
            selectedTag = null
        }
        store.baseUrl = url; baseUrl = url; api = a
        serverConfig = config
        rememberServer(url, config)
        screen = Screen.Home
        items = a.items()
    }

    fun connectSaved(server: SavedServer) = connect(server.url)

    fun removeSavedServer(server: SavedServer) {
        store.removeServer(server.url)
        savedServers = store.savedServers
        notice = "Removed ${server.name} from saved servers."
    }

    fun refresh() = launch {
        val a = requireApi()
        serverConfig = a.config()
        baseUrl?.let { updateSavedServerName(it, serverConfig!!) }
        items = a.items()
    }

    fun openItem(id: Int) {
        detail = null
        go(Screen.Detail(id))
        launch { detail = requireApi().detail(id) }
    }

    fun addItem(name: String, description: String, imageUrl: String, rawTags: String) = launch {
        if (token == null) throw ApiException("Log in before adding an item")
        val tags = rawTags.split(',').map { it.trim() }.filter { it.isNotEmpty() }.distinctBy { it.lowercase() }
        if (tags.size > 8) throw ApiException("Use no more than 8 tags")
        val result = requireApi().submitItem(name.trim(), description.trim(), imageUrl.trim(), tags)
        items = requireApi().items()
        screen = Screen.Home
        notice = when (result) {
            SubmissionResult.Published -> "Item published. Added by ${username ?: "you"}."
            SubmissionResult.Suggested -> "Suggestion sent to the server admin for review."
        }
    }

    fun submitReview(id: Int, rating: Int, text: String, onDone: () -> Unit) = launch {
        if (rating == 0) throw ApiException("Pick a rating from 1 to 10 first")
        val a = requireApi()
        a.postReview(id, rating, text)
        detail = a.detail(id)
        items = a.items()
        notice = if (token != null) "Review saved" else "Thanks for your review!"
        onDone()
    }

    fun deleteMyReview(id: Int) = launch {
        val a = requireApi()
        a.deleteMyReview(id)
        detail = a.detail(id)
        items = a.items()
        notice = "Review deleted"
    }

    fun reportContent(type: String, id: Int, reason: String) = launch {
        if (token == null) throw ApiException("Log in to report content")
        val a = requireApi()
        a.report(type, id, reason.trim())
        if (type == "item" && screen is Screen.Detail) detail = a.detail(id)
        notice = "Report sent to the server moderators."
    }

    fun auth(login: Boolean, user: String, pass: String) = launch {
        val a = requireApi()
        val r = if (login) a.login(user.trim(), pass) else a.signup(user.trim(), pass)
        store.token = r.token; store.username = r.username
        token = r.token; username = r.username
        screen = Screen.Home
        items = a.items()
    }

    fun logout() {
        store.token = null; store.username = null
        token = null; username = null
    }
}
